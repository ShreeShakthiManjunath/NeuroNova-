package com.example.neuronova

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
