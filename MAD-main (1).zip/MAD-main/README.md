# NeuroNova - Smart AI Neurological Screening Platform

[![Flutter](https://img.shields.io/badge/Flutter-3.x-02569B?logo=flutter)](https://flutter.dev)
[![Dart](https://img.shields.io/badge/Dart-3.x-0175C2?logo=dart)](https://dart.dev)
[![Gemini AI](https://img.shields.io/badge/AI-Gemini%201.5%20Flash-8E44AD?logo=google-gemini)](https://deepmind.google/technologies/gemini/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

**NeuroNova** is an advanced mobile health (mHealth) platform designed for early screening, continuous monitoring, and 3D anatomical visualization of neurological indicators—such as vocal micro-tremors, cognitive memory recall, and postural balance sway.

---

## 🌟 Key Features

### 🧍 3D Anatomical Body Analysis (`Anatomical3dBodyWidget`)
- **Vector Anatomical Silhouette**: Medical-grade custom vector drawing of human body structures (Head, Cervical Spine, Shoulders, Arms, Wrists, Torso, Pelvis, Knees, Ankles, Feet).
- **Interactive 3D Pan Rotation**: Drag horizontally on the canvas to rotate the body 360° with dynamic perspective matrix skews.
- **Anatomical Heatmaps**: Color-coded radial gradient hotspots over affected areas (Red: High Tremor, Amber: Moderate, Green: Stable).
- **Interactive Joint Nodes & Radar Pulses**: Tap any joint or limb node to view real-time frequency (Hz), sway angle (°), and clinical notes.
- **Laser Scanline Sweep**: Animated vertical laser sweep with holographic grid overlay.
- **Anterior & Posterior View Switcher**: Instant view toggle between front and back anatomical angles.

### 💬 Interactive Gemini AI Health Assistant Chatbot
- **Conversational Health Assistant**: Replaces static reports with a real-time conversational chat interface (`Gemini Neural Health Assistant`).
- **Context-Aware Diagnostics**: Evaluates patient memory score, voice tremor index, pitch stability, and reported symptoms to answer patient questions.
- **Embedded Health Synthesis Cards**: Renders composite health scores (e.g. 82/100) and risk badges directly inside the chat stream.
- **Quick Prompt Chips Bar**: One-tap suggested questions (*"What does my score mean?"*, *"How to lower voice tremor?"*, *"Should I see a doctor?"*).
- **Animated Typing Indicator**: Visual feedback while Gemini synthesizes health advice.

### 🤖 NeuroNova Assistant (App-Wide Project Chatbot)
- **Always one tap away**: "Ask NeuroNova" floating button on the Home screen (`/assistant`).
- **Knows the project**: Explains the Voice, Memory and Symptom tests, 3D Body Map, Neuro Cube sensors, risk levels and reports.
- **Smart shortcuts**: Replies can include a button that opens the relevant screen (e.g. *Open Voice Test*).
- **Safety-first**: Emergency phrases (stroke signs, chest pain, self-harm) immediately advise calling local emergency services and link to Emergency SOS.
- **Works offline**: Uses Gemini when `GEMINI_API_KEY` is set, otherwise a built-in knowledge base (`neuronova_assistant_service.dart`).

### 📊 Analysis Visualization Charts
Built with Flutter `CustomPainter` (no extra packages) in `widgets/analysis_charts.dart`, all animated on load:
- **Radar chart** (Test Results Overview): all five test scores vs. the 75 low-risk threshold.
- **Interactive pie charts** (Test Results Overview, Risk Report): tap a slice or legend row and it pops out with value and share; the Risk Report pie shows which domains contribute most to risk.
- **Trend line chart** (Daily Progress): smooth curve with axes, value labels and a per-test selector (Overall, Voice, Memory, Tremor, Tapping, Balance).
- **Tap-to-inspect bar charts** (Daily Progress, AI Analysis chat): risk-colored bars with a low-risk threshold line and a tooltip showing the value and risk band.
- **Then-vs-Now grouped bars** (Daily Progress): first session vs latest, with ▲/▼ change badges per test.
- **Gauge** (Risk Report): composite index ring.
- Demo data lives in `utils/screening_data.dart` so every chart stays consistent; swap it for SQLite results when ready.

### 🧠 Adaptive AI Symptom Screener
- **4-Stage Dynamic Nested Questions**: Powered by Gemini AI to dynamically narrow down specific neurological symptom progression (Tremors, Memory, Balance, Speech).
- **Clinical Summary Synthesis**: Generates structured executive summaries and actionable recommendation plans.

### 🎙️ Vocal Acoustic Stability Assessment
- **Micro-Tremor Spectrum Analysis**: Evaluates voice resonance, tremor index, and pitch stability sustain during prompt phrase readings.
- **Interactive Waveform Visualizer**: Live audio frequency visualizer during speech sampling.

### 🕹️ Sequence Memory Screening
- **Cognitive Recall Testing**: Multi-level visual & sequence memory challenges to track cognitive precision and reaction latency over time.

### 🔌 Smart Hardware Integration (Neuro Cube)
- **Bluetooth Sensor Connectivity**: Pair and monitor wearable IMU sensor badges (Wrist, Lumbar, Ankle) with live status updates.

### 🚨 Emergency Safety & Caregiver SOS
- **1-Tap Distress Dispatch**: Instantly dispatches distress alerts and caregiver notifications.
- **Registered Caregivers Directory**: Quick access to primary physicians and emergency contact numbers.

---

## 🏗️ Technical Architecture & Stack

- **Frontend Framework**: Flutter (Dart 3.x) with responsive multi-dimension support across compact, standard, and large screen devices.
- **State & Theme**: Tailwind-inspired modular design system (`TailwindTheme`, `AppColors`).
- **AI Neural Engine**: Google Gemini API (`google_generative_ai`) with intelligent offline heuristic fallbacks.
- **Database & Local Storage**: SQLite (`sqflite`) for encrypted patient screening logs & `shared_preferences` for session state.
- **Authentication**: Firebase Authentication & Google OAuth (with seamless developer fallback mode).

---

## 📁 Project Directory Structure

```text
lib/
├── main.dart                      # Application Entry Point & Route Definitions
├── models/                        # Data Structures & Models
├── screens/
│   ├── ai_analysis_screen.dart    # Interactive AI Chatbot & Clinical Synthesis
│   ├── analysis_3d_screen.dart    # 3D Anatomical Analysis & Heatmap View
│   ├── connect_cube_screen.dart   # Hardware Sensor Pairing
│   ├── daily_progress_screen.dart # Trend Analytics & Historical Graphs
│   ├── device_status_screen.dart  # Sensor Status & Battery Diagnostics
│   ├── doctor_screen.dart         # Physician Report & PDF Export View
│   ├── emergency_sos_screen.dart  # Caregiver Emergency SOS Dispatch
│   ├── history_screen.dart        # SQLite Test Record Archive
│   ├── home_screen.dart           # Primary Patient Dashboard
│   ├── login_screen.dart          # User Authentication & OAuth
│   ├── memory_test_screen.dart    # Cognitive Sequence Screening
│   ├── neuronova_assistant_screen.dart # NeuroNova Assistant Chatbot UI
│   ├── registration_screen.dart   # User Account Creation
│   ├── splash_screen.dart         # Adaptive Brand Launch Screen
│   ├── symptom_screen.dart        # 4-Stage Adaptive AI Screener
│   └── voice_test_screen.dart     # Vocal Tremor & Pitch Assessment
├── services/
│   ├── auth_service.dart          # Authentication & Session Manager
│   ├── database_helper.dart       # SQLite Database Helper
│   ├── gemini_service.dart        # Gemini 1.5 Flash AI Service
│   └── neuronova_assistant_service.dart # Assistant brain (Gemini + offline KB)
├── utils/
│   ├── screening_data.dart        # Shared demo scores & trend data for charts
│   ├── app_colors.dart            # Golden Amber Color Palette Token System
│   └── tailwind_theme.dart        # Modular Utility Typography & Card System
└── widgets/
    ├── analysis_charts.dart       # Radar, Bar, Trend, Donut/Gauge chart widgets
    ├── anatomical_3d_body_widget.dart # Vector 3D Body CustomPainter & Heatmap
    └── loading_widget.dart        # Animated Neural Engine Loaders
```

---

## 🚀 Getting Started

### Prerequisites
- [Flutter SDK](https://docs.flutter.dev/get-started/install) (v3.10.0 or higher)
- [Dart SDK](https://dart.dev/get-started) (v3.0.0 or higher)
- Xcode (for iOS/macOS) or Android Studio (for Android)

### Installation

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/dharshini-star/MAD.git
   cd MAD
   ```

2. **Install Dependencies**:
   ```bash
   flutter pub get
   ```

3. **Configure Gemini API Key** (Optional for live Gemini API calls):
   ```bash
   flutter run --dart-define=GEMINI_API_KEY=YOUR_GEMINI_API_KEY
   ```
   *Note: If no API key is provided, NeuroNova automatically utilizes its built-in intelligent clinical fallback engine.*

4. **Run the Application**:
   ```bash
   flutter run
   ```

---

## 🧪 Code Quality & Verification

Run static analysis to verify code health:
```bash
flutter analyze lib/
```

---

## 📜 License

This project is open source and available under the [MIT License](LICENSE).
