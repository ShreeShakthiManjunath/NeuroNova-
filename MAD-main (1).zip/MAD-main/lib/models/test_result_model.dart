import 'package:flutter/material.dart';
import '../utils/app_colors.dart';

class TestResultModel {
  final String resultId;
  final String date;
  
  // Specific screening sub-scores matching the blueprint's metrics out of 100
  final int voiceScore;
  final int memoryScore;
  final int handTremorScore;
  final int fingerTappingScore;
  final int balanceScore;

  const TestResultModel({
    required this.resultId,
    required this.date,
    required this.voiceScore,
    required this.memoryScore,
    required this.handTremorScore,
    required this.fingerTappingScore,
    required this.balanceScore,
  });

  // Derived field to compute overall performance score dynamically
  int get overallScore {
    return ((voiceScore + memoryScore + handTremorScore + fingerTappingScore + balanceScore) / 5).round();
  }

  // Matches Screen 3 and 13 metrics directly with the blueprint data boundaries
  String get riskLevel {
    int score = overallScore;
    if (score >= 75) return "Low Risk";
    if (score >= 60) return "Moderate Risk";
    return "High Risk";
  }

  // Maps theme colors to the risk evaluation for immediate UI rendering
  Color get riskColor {
    switch (riskLevel) {
      case "Low Risk":
        return AppColors.riskLow;
      case "Moderate Risk":
        return AppColors.riskModerate;
      default:
        return AppColors.riskHigh;
    }
  }

  factory TestResultModel.fromMap(Map<String, dynamic> map) {
    return TestResultModel(
      resultId: map['resultId'] ?? '',
      date: map['date'] ?? '',
      voiceScore: map['voiceScore']?.toInt() ?? 0,
      memoryScore: map['memoryScore']?.toInt() ?? 0,
      handTremorScore: map['handTremorScore']?.toInt() ?? 0,
      fingerTappingScore: map['fingerTappingScore']?.toInt() ?? 0,
      balanceScore: map['balanceScore']?.toInt() ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'resultId': resultId,
      'date': date,
      'voiceScore': voiceScore,
      'memoryScore': memoryScore,
      'handTremorScore': handTremorScore,
      'fingerTappingScore': fingerTappingScore,
      'balanceScore': balanceScore,
    };
  }
}