class UserModel {
  final String id;
  final String name;
  final String email;
  final String? medicalId; // Optional practitioner code if doctor profile
  final bool isDoctor;

  const UserModel({
    required this.id,
    required this.name,
    required this.email,
    this.medicalId,
    required this.isDoctor,
  });

  // Convert map from database/API to runtime Object model
  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      medicalId: map['medicalId'],
      isDoctor: map['isDoctor'] ?? false,
    );
  }

  // Convert Object model back to structured Map for JSON/Database writes
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'medicalId': medicalId,
      'isDoctor': isDoctor,
    };
  }
}