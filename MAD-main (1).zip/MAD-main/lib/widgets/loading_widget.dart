import 'package:flutter/material.dart';
import '../utils/app_colors.dart';

class LoadingWidget extends StatelessWidget {
  final double size;
  final String? statusText;

  const LoadingWidget({
    super.key,
    this.size = 120.0,
    this.statusText,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: size,
              height: size,
              child: CircularProgressIndicator(
                strokeWidth: 4,
                valueColor: AlwaysStoppedAnimation<Color>(
                  AppColors.primaryBlue.withValues(alpha: 0.3),
                ),
              ),
            ),
            SizedBox(
              width: size - 20,
              height: size - 20,
              child: const CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryBlue),
              ),
            ),
            const Icon(Icons.blur_on, size: 40, color: AppColors.primaryBlue),
          ],
        ),
        if (statusText != null) ...[
          const SizedBox(height: 24),
          Text(
            statusText!,
            style: const TextStyle(
              color: AppColors.textMain,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ],
    );
  }
}