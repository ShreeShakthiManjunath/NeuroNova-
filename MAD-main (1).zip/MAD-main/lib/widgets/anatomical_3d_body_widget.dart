import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../utils/app_colors.dart';

enum AnatomicalRegionType {
  head,
  neck,
  leftShoulder,
  rightShoulder,
  leftWrist,
  rightWrist,
  spine,
  lumbar,
  leftKnee,
  rightKnee,
  leftAnkle,
  rightAnkle,
}

class AnatomicalRegion {
  final AnatomicalRegionType type;
  final String name;
  final String location;
  final Offset relativePos; // (x: -1..1, y: -1..1) where (0,0) is center of body
  final double tremorFreq; // Hz
  final double swayAngle; // degrees
  final double intensity; // 0.0 - 1.0
  final Color statusColor;
  final String statusText;
  final String clinicalNote;

  const AnatomicalRegion({
    required this.type,
    required this.name,
    required this.location,
    required this.relativePos,
    required this.tremorFreq,
    required this.swayAngle,
    required this.intensity,
    required this.statusColor,
    required this.statusText,
    required this.clinicalNote,
  });
}

class Anatomical3dBodyWidget extends StatefulWidget {
  final int activeTab; // 0: Tremor Map, 1: Balance Map
  final bool isAnterior;
  final double rotationY;
  final bool showHeatmap;
  final bool showSkeleton;
  final bool showSensors;
  final AnatomicalRegion? selectedRegion;
  final ValueChanged<AnatomicalRegion> onRegionSelected;

  const Anatomical3dBodyWidget({
    super.key,
    required this.activeTab,
    required this.isAnterior,
    required this.rotationY,
    this.showHeatmap = true,
    this.showSkeleton = true,
    this.showSensors = true,
    required this.selectedRegion,
    required this.onRegionSelected,
  });

  @override
  State<Anatomical3dBodyWidget> createState() => _Anatomical3dBodyWidgetState();
}

class _Anatomical3dBodyWidgetState extends State<Anatomical3dBodyWidget>
    with TickerProviderStateMixin {
  late AnimationController _scanController;
  late AnimationController _pulseController;

  static const List<AnatomicalRegion> tremorRegions = [
    AnatomicalRegion(
      type: AnatomicalRegionType.rightWrist,
      name: 'Right Wrist & Hand',
      location: 'Upper Extremity (Distal)',
      relativePos: Offset(0.42, -0.05),
      tremorFreq: 6.8,
      swayAngle: 14.2,
      intensity: 0.85,
      statusColor: AppColors.riskHigh,
      statusText: 'High Tremor (6.8 Hz)',
      clinicalNote: 'Postural tremor detected during steady holding tasks. Elevated resting amplitude.',
    ),
    AnatomicalRegion(
      type: AnatomicalRegionType.leftWrist,
      name: 'Left Wrist & Hand',
      location: 'Upper Extremity (Distal)',
      relativePos: Offset(-0.42, -0.05),
      tremorFreq: 4.1,
      swayAngle: 8.5,
      intensity: 0.55,
      statusColor: AppColors.riskModerate,
      statusText: 'Moderate Tremor (4.1 Hz)',
      clinicalNote: 'Mild action tremor observed. Symmetric tracking recommended.',
    ),
    AnatomicalRegion(
      type: AnatomicalRegionType.head,
      name: 'Cranial & Neck Region',
      location: 'Axial / Cervical',
      relativePos: Offset(0.0, -0.80),
      tremorFreq: 2.3,
      swayAngle: 3.1,
      intensity: 0.25,
      statusColor: AppColors.riskLow,
      statusText: 'Normal Resting Tone',
      clinicalNote: 'Head titubation within physiological baseline parameters.',
    ),
    AnatomicalRegion(
      type: AnatomicalRegionType.spine,
      name: 'Thoracic Spine',
      location: 'Axial Column',
      relativePos: Offset(0.0, -0.30),
      tremorFreq: 3.5,
      swayAngle: 5.2,
      intensity: 0.40,
      statusColor: AppColors.primaryAmber,
      statusText: 'Mild Axis Vibration',
      clinicalNote: 'Low-frequency axial muscular tone flutter detected.',
    ),
  ];

  static const List<AnatomicalRegion> balanceRegions = [
    AnatomicalRegion(
      type: AnatomicalRegionType.lumbar,
      name: 'Lumbar Center of Mass',
      location: 'L3-L5 Core Axis',
      relativePos: Offset(0.0, 0.10),
      tremorFreq: 1.8,
      swayAngle: 12.4,
      intensity: 0.75,
      statusColor: AppColors.riskModerate,
      statusText: 'Elevated Postural Sway',
      clinicalNote: 'Anteroposterior center-of-pressure displacement increased during quiet stance.',
    ),
    AnatomicalRegion(
      type: AnatomicalRegionType.rightKnee,
      name: 'Right Knee Joint',
      location: 'Lower Extremity (Right)',
      relativePos: Offset(0.18, 0.45),
      tremorFreq: 1.2,
      swayAngle: 9.8,
      intensity: 0.65,
      statusColor: AppColors.primaryAmber,
      statusText: 'Asymmetric Weight Load',
      clinicalNote: 'Unilateral stance compensation shifting load to right quadriceps.',
    ),
    AnatomicalRegion(
      type: AnatomicalRegionType.leftKnee,
      name: 'Left Knee Joint',
      location: 'Lower Extremity (Left)',
      relativePos: Offset(-0.18, 0.45),
      tremorFreq: 0.9,
      swayAngle: 4.2,
      intensity: 0.20,
      statusColor: AppColors.riskLow,
      statusText: 'Stable Joint Alignment',
      clinicalNote: 'Normal extensor vector stability without sway elevation.',
    ),
    AnatomicalRegion(
      type: AnatomicalRegionType.rightAnkle,
      name: 'Right Ankle Base',
      location: 'Lower Extremity (Distal Foot)',
      relativePos: Offset(0.22, 0.85),
      tremorFreq: 1.5,
      swayAngle: 11.1,
      intensity: 0.70,
      statusColor: AppColors.riskHigh,
      statusText: 'Proprioceptive Correction High',
      clinicalNote: 'Frequent ankle strategy micro-adjustments detected.',
    ),
    AnatomicalRegion(
      type: AnatomicalRegionType.leftAnkle,
      name: 'Left Ankle Base',
      location: 'Lower Extremity (Distal Foot)',
      relativePos: Offset(-0.22, 0.85),
      tremorFreq: 1.1,
      swayAngle: 5.0,
      intensity: 0.30,
      statusColor: AppColors.riskLow,
      statusText: 'Stable Base Support',
      clinicalNote: 'Sub-threshold postural correction response.',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _scanController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();
  }

  @override
  void dispose() {
    _scanController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  List<AnatomicalRegion> get _currentRegions =>
      widget.activeTab == 0 ? tremorRegions : balanceRegions;

  void _handleTap(TapUpDetails details, Size canvasSize) {
    final Offset tapPos = details.localPosition;
    final Offset center = Offset(canvasSize.width / 2, canvasSize.height / 2);

    AnatomicalRegion? closestRegion;
    double minDistance = double.infinity;

    for (final region in _currentRegions) {
      // Calculate projected region coordinate on canvas
      final double projectedX = center.dx + (region.relativePos.dx * (canvasSize.width * 0.38) * math.cos(widget.rotationY));
      final double projectedY = center.dy + (region.relativePos.dy * (canvasSize.height * 0.42));
      final Offset regionPos = Offset(projectedX, projectedY);

      final double dist = (tapPos - regionPos).distance;
      if (dist < 45.0 && dist < minDistance) {
        minDistance = dist;
        closestRegion = region;
      }
    }

    if (closestRegion != null) {
      widget.onRegionSelected(closestRegion);
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final Size size = Size(constraints.maxWidth, constraints.maxHeight);

        return GestureDetector(
          onTapUp: (details) => _handleTap(details, size),
          child: AnimatedBuilder(
            animation: Listenable.merge([_scanController, _pulseController]),
            builder: (context, child) {
              return CustomPaint(
                size: size,
                painter: AnatomicalBodyPainter(
                  activeTab: widget.activeTab,
                  isAnterior: widget.isAnterior,
                  rotationY: widget.rotationY,
                  showHeatmap: widget.showHeatmap,
                  showSkeleton: widget.showSkeleton,
                  showSensors: widget.showSensors,
                  scanProgress: _scanController.value,
                  pulseProgress: _pulseController.value,
                  regions: _currentRegions,
                  selectedRegion: widget.selectedRegion,
                ),
              );
            },
          ),
        );
      },
    );
  }
}

class AnatomicalBodyPainter extends CustomPainter {
  final int activeTab;
  final bool isAnterior;
  final double rotationY;
  final bool showHeatmap;
  final bool showSkeleton;
  final bool showSensors;
  final double scanProgress;
  final double pulseProgress;
  final List<AnatomicalRegion> regions;
  final AnatomicalRegion? selectedRegion;

  AnatomicalBodyPainter({
    required this.activeTab,
    required this.isAnterior,
    required this.rotationY,
    required this.showHeatmap,
    required this.showSkeleton,
    required this.showSensors,
    required this.scanProgress,
    required this.pulseProgress,
    required this.regions,
    required this.selectedRegion,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Offset center = Offset(size.width / 2, size.height / 2 + 10);
    final double bodyScaleX = size.width * 0.38;
    final double bodyScaleY = size.height * 0.42;

    // 1. Draw Holographic Grid & Background Radial Glow
    _drawBackgroundGrid(canvas, size, center);

    // Apply 3D perspective rotation transformation
    canvas.save();
    canvas.translate(center.dx, center.dy);

    final double cosR = math.cos(rotationY);
    final double sinR = math.sin(rotationY);

    // 2. Draw Body Silhouette Paths
    _drawBodySilhouette(canvas, bodyScaleX, bodyScaleY, cosR, sinR);

    // 3. Draw Skeleton & Joint Node Network
    if (showSkeleton) {
      _drawSkeletonNodes(canvas, bodyScaleX, bodyScaleY, cosR);
    }

    // 4. Draw Heatmap Hotspot Blobs
    if (showHeatmap) {
      _drawHeatmaps(canvas, bodyScaleX, bodyScaleY, cosR);
    }

    // 5. Draw Wearable Sensor IMU Badges
    if (showSensors) {
      _drawSensorBadges(canvas, bodyScaleX, bodyScaleY, cosR);
    }

    // 6. Draw Region Hotspot Touch Nodes & Pulsing Rings
    _drawRegionNodes(canvas, bodyScaleX, bodyScaleY, cosR);

    canvas.restore();

    // 7. Draw Laser Scanline Effect (Un-transformed overlay)
    _drawScanline(canvas, size);
  }

  void _drawBackgroundGrid(Canvas canvas, Size size, Offset center) {
    // Soft radial ambient light
    final Paint bgGlowPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          AppColors.primaryAmber.withValues(alpha: 0.12),
          AppColors.primaryAmber.withValues(alpha: 0.03),
          Colors.transparent,
        ],
        stops: const [0.0, 0.6, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: size.width * 0.5));
    canvas.drawCircle(center, size.width * 0.5, bgGlowPaint);

    // Futuristic matrix subtle grid lines
    final Paint gridPaint = Paint()
      ..color = AppColors.cardBorder.withValues(alpha: 0.35)
      ..strokeWidth = 0.8;

    const double step = 30.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
  }

  void _drawBodySilhouette(Canvas canvas, double sx, double sy, double cosR, double sinR) {
    final Paint fillPaint = Paint()
      ..color = AppColors.primaryAmber.withValues(alpha: 0.08)
      ..style = PaintingStyle.fill;

    final Paint borderPaint = Paint()
      ..color = AppColors.primaryAmber.withValues(alpha: 0.7)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final Paint glowPaint = Paint()
      ..color = AppColors.primaryGold.withValues(alpha: 0.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5.0
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);

    // Scaled anatomical model coordinates relative to (0,0) center
    // 3D perspective distortion applies to X coordinates based on cosR & offset depth
    double transformX(double x, double z) {
      return (x * cosR + z * sinR) * sx;
    }

    double transformY(double y) => y * sy;

    final Path bodyPath = Path();

    // Head (Oval)
    final Offset headCenter = Offset(transformX(0, 0), transformY(-0.80));
    final double headRx = 0.11 * sx * (0.85 + 0.15 * cosR.abs());
    final double headRy = 0.11 * sy;
    bodyPath.addOval(Rect.fromCenter(center: headCenter, width: headRx * 2, height: headRy * 2));

    // Neck
    bodyPath.moveTo(transformX(-0.06, 0), transformY(-0.68));
    bodyPath.lineTo(transformX(-0.08, 0), transformY(-0.61));
    bodyPath.lineTo(transformX(-0.28, 0), transformY(-0.55)); // Left Shoulder

    // Left Arm (Upper -> Forearm -> Hand)
    bodyPath.lineTo(transformX(-0.36, 0), transformY(-0.25)); // Left Elbow
    bodyPath.lineTo(transformX(-0.43, 0), transformY(-0.02)); // Left Wrist
    bodyPath.lineTo(transformX(-0.46, 0), transformY(0.08));  // Left Hand Tip
    bodyPath.lineTo(transformX(-0.39, 0), transformY(0.06));
    bodyPath.lineTo(transformX(-0.31, 0), transformY(-0.22)); // Inside Elbow
    bodyPath.lineTo(transformX(-0.22, 0), transformY(-0.40)); // Left Axilla / Armpit

    // Torso Left Side -> Hip
    bodyPath.lineTo(transformX(-0.19, 0), transformY(-0.15)); // Waist
    bodyPath.lineTo(transformX(-0.22, 0), transformY(0.12));  // Left Hip

    // Left Leg (Thigh -> Knee -> Ankle -> Foot)
    bodyPath.lineTo(transformX(-0.19, 0), transformY(0.46)); // Left Knee
    bodyPath.lineTo(transformX(-0.21, 0), transformY(0.82)); // Left Ankle
    bodyPath.lineTo(transformX(-0.28, 0), transformY(0.92)); // Left Foot Toe
    bodyPath.lineTo(transformX(-0.15, 0), transformY(0.92)); // Left Heel inside
    bodyPath.lineTo(transformX(-0.10, 0), transformY(0.80)); // Inside Ankle
    bodyPath.lineTo(transformX(-0.08, 0), transformY(0.44)); // Inside Knee
    bodyPath.lineTo(transformX(-0.02, 0), transformY(0.15)); // Groin

    // Right Leg (Mirroring with perspective X)
    bodyPath.lineTo(transformX(0.02, 0), transformY(0.15));  // Groin
    bodyPath.lineTo(transformX(0.08, 0), transformY(0.44));  // Inside Right Knee
    bodyPath.lineTo(transformX(0.10, 0), transformY(0.80));  // Inside Right Ankle
    bodyPath.lineTo(transformX(0.15, 0), transformY(0.92));  // Right Heel inside
    bodyPath.lineTo(transformX(0.28, 0), transformY(0.92));  // Right Foot Toe
    bodyPath.lineTo(transformX(0.21, 0), transformY(0.82));  // Right Ankle
    bodyPath.lineTo(transformX(0.19, 0), transformY(0.46));  // Right Knee
    bodyPath.lineTo(transformX(0.22, 0), transformY(0.12));  // Right Hip

    // Torso Right Side -> Armpit
    bodyPath.lineTo(transformX(0.19, 0), transformY(-0.15)); // Right Waist
    bodyPath.lineTo(transformX(0.22, 0), transformY(-0.40)); // Right Axilla / Armpit

    // Right Arm (Armpit -> Inside Elbow -> Hand -> Outer Elbow -> Shoulder)
    bodyPath.lineTo(transformX(0.31, 0), transformY(-0.22)); // Inside Elbow
    bodyPath.lineTo(transformX(0.39, 0), transformY(0.06));
    bodyPath.lineTo(transformX(0.46, 0), transformY(0.08));  // Right Hand Tip
    bodyPath.lineTo(transformX(0.43, 0), transformY(-0.02)); // Right Wrist
    bodyPath.lineTo(transformX(0.36, 0), transformY(-0.25)); // Right Elbow
    bodyPath.lineTo(transformX(0.28, 0), transformY(-0.55)); // Right Shoulder

    // Neck Right
    bodyPath.lineTo(transformX(0.08, 0), transformY(-0.61));
    bodyPath.lineTo(transformX(0.06, 0), transformY(-0.68));

    bodyPath.close();

    // Draw Glow and Body Path
    canvas.drawPath(bodyPath, glowPaint);
    canvas.drawPath(bodyPath, fillPaint);
    canvas.drawPath(bodyPath, borderPaint);

    // Muscle Contour Anatomical Overlay Lines
    _drawAnatomicalContours(canvas, sx, sy, cosR, transformX, transformY);
  }

  void _drawAnatomicalContours(
    Canvas canvas,
    double sx,
    double sy,
    double cosR,
    double Function(double x, double z) tx,
    double Function(double y) ty,
  ) {
    final Paint linePaint = Paint()
      ..color = AppColors.cardBorder.withValues(alpha: 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;

    // Pectoral / Chest Arc
    final Path chestPath = Path();
    chestPath.moveTo(tx(-0.22, 0), ty(-0.42));
    chestPath.quadraticBezierTo(tx(0, 0), ty(-0.35), tx(0.22, 0), ty(-0.42));
    canvas.drawPath(chestPath, linePaint);

    // Ribcage / Abdominal grid lines
    for (double yNorm in [-0.30, -0.22, -0.14]) {
      canvas.drawLine(
        Offset(tx(-0.14, 0), ty(yNorm)),
        Offset(tx(0.14, 0), ty(yNorm)),
        linePaint,
      );
    }

    // Spine Central Axis Line
    final Paint spineLinePaint = Paint()
      ..color = AppColors.primaryAmber.withValues(alpha: 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final Path spinePath = Path();
    spinePath.moveTo(tx(0, 0), ty(-0.68));
    spinePath.lineTo(tx(0, 0), ty(0.12));
    canvas.drawPath(spinePath, spineLinePaint);
  }

  void _drawSkeletonNodes(Canvas canvas, double sx, double sy, double cosR) {
    final Paint bonePaint = Paint()
      ..color = Colors.cyan.withValues(alpha: 0.6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final Paint nodePaint = Paint()
      ..color = Colors.cyanAccent
      ..style = PaintingStyle.fill;

    Offset pt(double x, double y) => Offset(x * sx * cosR, y * sy);

    final joints = [
      pt(0, -0.80),    // Head
      pt(0, -0.65),    // Cervical
      pt(-0.28, -0.55),// L Shoulder
      pt(0.28, -0.55), // R Shoulder
      pt(-0.36, -0.25),// L Elbow
      pt(0.36, -0.25), // R Elbow
      pt(-0.43, -0.02),// L Wrist
      pt(0.43, -0.02), // R Wrist
      pt(0, -0.25),    // Thoracic Spine
      pt(0, 0.10),     // Pelvis
      pt(-0.19, 0.46), // L Knee
      pt(0.19, 0.46),  // R Knee
      pt(-0.21, 0.82), // L Ankle
      pt(0.21, 0.82),  // R Ankle
    ];

    // Connect skeleton lines
    void connect(int a, int b) {
      canvas.drawLine(joints[a], joints[b], bonePaint);
    }

    connect(0, 1);
    connect(1, 8);
    connect(8, 9);
    connect(1, 2);
    connect(1, 3);
    connect(2, 4);
    connect(4, 6);
    connect(3, 5);
    connect(5, 7);
    connect(9, 10);
    connect(10, 12);
    connect(9, 11);
    connect(11, 13);

    // Draw joint dots
    for (final j in joints) {
      canvas.drawCircle(j, 3.5, nodePaint);
    }
  }

  void _drawHeatmaps(Canvas canvas, double sx, double sy, double cosR) {
    for (final region in regions) {
      if (region.intensity <= 0.1) continue;

      final Offset center = Offset(region.relativePos.dx * sx * cosR, region.relativePos.dy * sy);
      final double radius = 38.0 * region.intensity;

      final Paint heatmapPaint = Paint()
        ..shader = RadialGradient(
          colors: [
            region.statusColor.withValues(alpha: 0.65),
            region.statusColor.withValues(alpha: 0.30),
            region.statusColor.withValues(alpha: 0.0),
          ],
          stops: const [0.0, 0.5, 1.0],
        ).createShader(Rect.fromCircle(center: center, radius: radius));

      canvas.drawCircle(center, radius, heatmapPaint);
    }
  }

  void _drawSensorBadges(Canvas canvas, double sx, double sy, double cosR) {
    final sensorPoints = [
      Offset(0.43 * sx * cosR, -0.02 * sy), // Right Wrist Sensor
      Offset(-0.43 * sx * cosR, -0.02 * sy),// Left Wrist Sensor
      Offset(0.0 * sx * cosR, 0.10 * sy),   // Lumbar IMU
      Offset(0.21 * sx * cosR, 0.82 * sy),  // Right Ankle IMU
    ];

    final Paint badgePaint = Paint()
      ..color = const Color(0xFF0EA5E9)
      ..style = PaintingStyle.fill;

    final Paint borderPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    for (final p in sensorPoints) {
      canvas.drawCircle(p, 5.0, badgePaint);
      canvas.drawCircle(p, 5.0, borderPaint);
    }
  }

  void _drawRegionNodes(Canvas canvas, double sx, double sy, double cosR) {
    for (final region in regions) {
      final Offset p = Offset(region.relativePos.dx * sx * cosR, region.relativePos.dy * sy);
      final bool isSelected = selectedRegion?.type == region.type;

      // Base Node Outer Ring
      final Paint outerRingPaint = Paint()
        ..color = region.statusColor.withValues(alpha: 0.4)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0;
      canvas.drawCircle(p, 10.0, outerRingPaint);

      // Core Solid Point
      final Paint corePaint = Paint()
        ..color = region.statusColor
        ..style = PaintingStyle.fill;
      canvas.drawCircle(p, 5.0, corePaint);

      // If selected or high tremor, draw pulsing radar animation ring
      if (isSelected || region.intensity > 0.7) {
        final double pulseRadius = 10.0 + (pulseProgress * 18.0);
        final double pulseOpacity = (1.0 - pulseProgress).clamp(0.0, 1.0);

        final Paint pulsePaint = Paint()
          ..color = region.statusColor.withValues(alpha: pulseOpacity * 0.7)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.0;

        canvas.drawCircle(p, pulseRadius, pulsePaint);
      }

      // Target reticle crosshairs for active selected region
      if (isSelected) {
        final Paint reticlePaint = Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5;

        canvas.drawCircle(p, 16.0, reticlePaint);

        const double armLen = 6.0;
        canvas.drawLine(Offset(p.dx - 20, p.dy), Offset(p.dx - 20 + armLen, p.dy), reticlePaint);
        canvas.drawLine(Offset(p.dx + 20, p.dy), Offset(p.dx + 20 - armLen, p.dy), reticlePaint);
        canvas.drawLine(Offset(p.dx, p.dy - 20), Offset(p.dx, p.dy - 20 + armLen), reticlePaint);
        canvas.drawLine(Offset(p.dx, p.dy + 20), Offset(p.dx, p.dy + 20 - armLen), reticlePaint);
      }
    }
  }

  void _drawScanline(Canvas canvas, Size size) {
    final double scanY = scanProgress * size.height;

    // Laser Beam Sweep Gradient
    final Paint laserGradientPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          AppColors.primaryAmber.withValues(alpha: 0.0),
          AppColors.primaryAmber.withValues(alpha: 0.18),
          AppColors.primaryGold.withValues(alpha: 0.50),
          AppColors.primaryAmber.withValues(alpha: 0.0),
        ],
        stops: const [0.0, 0.7, 0.9, 1.0],
      ).createShader(Rect.fromLTWH(0, scanY - 35, size.width, 40));

    canvas.drawRect(Rect.fromLTWH(0, scanY - 35, size.width, 40), laserGradientPaint);

    // Laser Bright Beam Center Line
    final Paint beamLinePaint = Paint()
      ..color = AppColors.primaryGold.withValues(alpha: 0.85)
      ..strokeWidth = 1.8;

    canvas.drawLine(Offset(0, scanY), Offset(size.width, scanY), beamLinePaint);
  }

  @override
  bool shouldRepaint(covariant AnatomicalBodyPainter oldDelegate) {
    return oldDelegate.scanProgress != scanProgress ||
        oldDelegate.pulseProgress != pulseProgress ||
        oldDelegate.rotationY != rotationY ||
        oldDelegate.isAnterior != isAnterior ||
        oldDelegate.showHeatmap != showHeatmap ||
        oldDelegate.showSkeleton != showSkeleton ||
        oldDelegate.showSensors != showSensors ||
        oldDelegate.activeTab != activeTab ||
        oldDelegate.selectedRegion != selectedRegion;
  }
}
