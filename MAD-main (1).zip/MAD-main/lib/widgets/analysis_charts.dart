import 'dart:math' as math;

import 'package:flutter/foundation.dart' show listEquals;
import 'package:flutter/material.dart';

import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

// =============================================================================
// Shared helpers
// =============================================================================

/// Same risk bands used across the app: >=75 Low, 60-74 Moderate, <60 High.
Color scoreBandColor(num v) {
  if (v >= 75) return AppColors.riskLow;
  if (v >= 60) return AppColors.riskModerate;
  return AppColors.riskHigh;
}

String scoreBandLabel(num v) {
  if (v >= 75) return 'Low Risk';
  if (v >= 60) return 'Moderate Risk';
  return 'High Risk';
}

const Duration _kChartAnim = Duration(milliseconds: 900);

TextPainter _text(
  String text, {
  double size = 11,
  Color color = AppColors.textSecondary,
  FontWeight weight = FontWeight.w500,
  double maxWidth = 90,
}) {
  return TextPainter(
    text: TextSpan(
      text: text,
      style: TextStyle(fontSize: size, color: color, fontWeight: weight),
    ),
    textAlign: TextAlign.center,
    textDirection: TextDirection.ltr,
    textWidthBasis: TextWidthBasis.longestLine,
    maxLines: 1,
    ellipsis: '…',
  )..layout(maxWidth: maxWidth);
}

void _paintCentered(Canvas canvas, TextPainter tp, Offset center) {
  tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
}

void _dashedLine(Canvas canvas, Offset a, Offset b, Paint paint,
    {double dash = 5, double gap = 4}) {
  final total = (b - a).distance;
  if (total == 0) return;
  final dir = (b - a) / total;
  double d = 0;
  while (d < total) {
    final end = math.min(d + dash, total);
    canvas.drawLine(a + dir * d, a + dir * end, paint);
    d += dash + gap;
  }
}

// =============================================================================
// Card + legend building blocks
// =============================================================================

class ChartCard extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget child;
  final Widget? trailing;
  final EdgeInsetsGeometry margin;

  const ChartCard({
    super.key,
    required this.title,
    required this.child,
    this.subtitle,
    this.trailing,
    this.margin = const EdgeInsets.only(bottom: 16),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: margin,
      padding: const EdgeInsets.all(18),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textMain,
                      ),
                    ),
                    if (subtitle != null) ...[
                      const SizedBox(height: 2),
                      Text(subtitle!, style: TailwindTheme.caption),
                    ],
                  ],
                ),
              ),
              if (trailing != null) trailing!,
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class LegendItem {
  final String label;
  final Color color;
  const LegendItem(this.label, this.color);
}

class ChartLegend extends StatelessWidget {
  final List<LegendItem> items;
  const ChartLegend({super.key, required this.items});

  /// Low / Moderate / High risk bands.
  static const List<LegendItem> riskBands = [
    LegendItem('Low (75+)', AppColors.riskLow),
    LegendItem('Moderate (60-74)', AppColors.riskModerate),
    LegendItem('High (<60)', AppColors.riskHigh),
  ];

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 14,
      runSpacing: 6,
      children: [
        for (final item in items)
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: item.color,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              const SizedBox(width: 6),
              Text(item.label, style: TailwindTheme.caption),
            ],
          ),
      ],
    );
  }
}

// =============================================================================
// Radar (spider) chart
// =============================================================================

class ScoreRadarChart extends StatelessWidget {
  final List<String> labels;
  final List<double> values; // 0-100
  final double benchmark;
  final double height;

  const ScoreRadarChart({
    super.key,
    required this.labels,
    required this.values,
    this.benchmark = 75,
    this.height = 270,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: _kChartAnim,
      curve: Curves.easeOutCubic,
      builder: (context, t, _) => SizedBox(
        width: double.infinity,
        height: height,
        child: CustomPaint(
          painter: _RadarPainter(labels, values, benchmark, t),
        ),
      ),
    );
  }
}

class _RadarPainter extends CustomPainter {
  final List<String> labels;
  final List<double> values;
  final double benchmark;
  final double t;

  _RadarPainter(this.labels, this.values, this.benchmark, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final n = labels.length;
    if (n < 3) return;
    final center = size.center(Offset.zero);
    final radius = math.min(size.width, size.height) / 2 - 44;
    if (radius <= 0) return;

    double angle(int i) => -math.pi / 2 + 2 * math.pi * i / n;
    Offset pt(int i, double frac) =>
        center + Offset(math.cos(angle(i)), math.sin(angle(i))) * (radius * frac);

    // Grid rings + spokes
    final gridPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = AppColors.cardBorder;
    for (final f in const [0.25, 0.5, 0.75, 1.0]) {
      final path = Path()..moveTo(pt(0, f).dx, pt(0, f).dy);
      for (int i = 1; i < n; i++) {
        path.lineTo(pt(i, f).dx, pt(i, f).dy);
      }
      path.close();
      canvas.drawPath(path, gridPaint);
    }
    for (int i = 0; i < n; i++) {
      canvas.drawLine(center, pt(i, 1), gridPaint);
    }

    // Low-risk benchmark (dashed)
    final benchPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..color = AppColors.riskLow.withValues(alpha: 0.85);
    final double bf = (benchmark / 100).clamp(0.0, 1.0).toDouble();
    for (int i = 0; i < n; i++) {
      _dashedLine(canvas, pt(i, bf), pt((i + 1) % n, bf), benchPaint);
    }

    // Score polygon (animated outwards from the centre)
    final valuePath = Path();
    for (int i = 0; i < n; i++) {
      final f = (values[i].clamp(0, 100) / 100) * t;
      final p = pt(i, f);
      if (i == 0) {
        valuePath.moveTo(p.dx, p.dy);
      } else {
        valuePath.lineTo(p.dx, p.dy);
      }
    }
    valuePath.close();
    canvas.drawPath(
      valuePath,
      Paint()
        ..style = PaintingStyle.fill
        ..color = AppColors.primaryGold.withValues(alpha: 0.28),
    );
    canvas.drawPath(
      valuePath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5
        ..strokeJoin = StrokeJoin.round
        ..color = AppColors.primaryAmber,
    );

    // Dots + labels
    for (int i = 0; i < n; i++) {
      final v = values[i];
      final f = (v.clamp(0, 100) / 100) * t;
      final p = pt(i, f);
      canvas.drawCircle(p, 6, Paint()..color = Colors.white);
      canvas.drawCircle(p, 4.5, Paint()..color = scoreBandColor(v));

      final dir = Offset(math.cos(angle(i)), math.sin(angle(i)));
      final labelCenter = center + dir * (radius + 26);
      final name = _text(labels[i],
          size: 11, weight: FontWeight.w600, color: AppColors.textMain, maxWidth: 74);
      final val = _text('${v.round()}',
          size: 12, weight: FontWeight.bold, color: scoreBandColor(v));
      final cx = labelCenter.dx
          .clamp(name.width / 2 + 2, size.width - name.width / 2 - 2)
          .toDouble();
      _paintCentered(canvas, name, Offset(cx, labelCenter.dy - 7));
      _paintCentered(canvas, val, Offset(cx, labelCenter.dy + 8));
    }
  }

  @override
  bool shouldRepaint(covariant _RadarPainter old) =>
      old.t != t ||
      old.benchmark != benchmark ||
      !listEquals(old.values, values) ||
      !listEquals(old.labels, labels);
}

// =============================================================================
// Bar chart (tap a bar for a tooltip)
// =============================================================================

class ScoreBarChart extends StatefulWidget {
  final List<String> labels;
  final List<double> values; // 0-100
  final double benchmark;
  final double height;

  const ScoreBarChart({
    super.key,
    required this.labels,
    required this.values,
    this.benchmark = 75,
    this.height = 220,
  });

  @override
  State<ScoreBarChart> createState() => _ScoreBarChartState();
}

class _ScoreBarChartState extends State<ScoreBarChart> {
  static const double _left = 28.0, _right = 8.0;
  int? _selected;

  void _onTap(Offset local, double width) {
    final n = widget.values.length;
    if (n == 0) return;
    final slot = (width - _left - _right) / n;
    if (slot <= 0) return;
    final idx = ((local.dx - _left) / slot).floor();
    setState(() {
      _selected = (idx < 0 || idx >= n || idx == _selected) ? null : idx;
    });
  }

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: _kChartAnim,
      curve: Curves.easeOutCubic,
      builder: (context, t, _) => SizedBox(
        width: double.infinity,
        height: widget.height,
        child: LayoutBuilder(
          builder: (context, box) => GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: (d) => _onTap(d.localPosition, box.maxWidth),
            child: CustomPaint(
              painter: _BarPainter(
                widget.labels,
                widget.values,
                widget.benchmark,
                t,
                _selected,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _BarPainter extends CustomPainter {
  final List<String> labels;
  final List<double> values;
  final double benchmark;
  final double t;
  final int? selected;

  _BarPainter(this.labels, this.values, this.benchmark, this.t, this.selected);

  @override
  void paint(Canvas canvas, Size size) {
    final n = values.length;
    if (n == 0) return;
    const left = 28.0, right = 8.0, top = 22.0, bottom = 30.0;
    final w = size.width - left - right;
    final h = size.height - top - bottom;
    if (w <= 0 || h <= 0) return;
    double yOf(double v) => top + h * (1 - v / 100);

    // Grid + y labels
    final grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = AppColors.cardBorder;
    for (final v in const [0.0, 25.0, 50.0, 75.0, 100.0]) {
      final y = yOf(v);
      if (v == 0) {
        canvas.drawLine(Offset(left, y), Offset(left + w, y), grid);
      } else {
        _dashedLine(canvas, Offset(left, y), Offset(left + w, y), grid,
            dash: 3, gap: 4);
      }
      final tp = _text('${v.round()}', size: 10, color: AppColors.textMuted, maxWidth: 24);
      tp.paint(canvas, Offset(left - 6 - tp.width, y - tp.height / 2));
    }

    // Bars
    final slot = w / n;
    final barW = math.min(40.0, slot * 0.56);
    for (int i = 0; i < n; i++) {
      final v = values[i].clamp(0, 100).toDouble();
      final isSel = selected == i;
      final dim = selected != null && !isSel;
      final color = scoreBandColor(v).withValues(alpha: dim ? 0.45 : 1.0);
      final x = left + slot * i + slot / 2;
      final vh = h * (v / 100) * t;
      final rect = RRect.fromRectAndCorners(
        Rect.fromLTWH(x - barW / 2, top + h - vh, barW, vh),
        topLeft: const Radius.circular(8),
        topRight: const Radius.circular(8),
      );
      if (isSel) {
        canvas.drawShadow(
          Path()..addRRect(rect),
          Colors.black.withValues(alpha: 0.35),
          5,
          false,
        );
      }
      canvas.drawRRect(
        rect,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [color, color.withValues(alpha: dim ? 0.3 : 0.6)],
          ).createShader(rect.outerRect),
      );

      if (!isSel) {
        final val = _text('${values[i].round()}',
            size: 12,
            weight: FontWeight.bold,
            color: color.withValues(alpha: (dim ? 0.5 : 1.0) * t.clamp(0.0, 1.0)));
        _paintCentered(canvas, val, Offset(x, top + h - vh - 10));
      }

      final name = _text(labels[i],
          size: 11,
          weight: isSel ? FontWeight.bold : FontWeight.w500,
          color: isSel ? AppColors.textMain : AppColors.textSecondary,
          maxWidth: slot);
      _paintCentered(canvas, name, Offset(x, size.height - bottom / 2 + 3));
    }

    // Low-risk threshold line
    final by = yOf(benchmark);
    _dashedLine(
      canvas,
      Offset(left, by),
      Offset(left + w, by),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..color = AppColors.riskLow,
    );

    // Tooltip for the tapped bar
    final sel = selected;
    if (sel != null && sel < n && t > 0.95) {
      final v = values[sel].clamp(0, 100).toDouble();
      final x = left + slot * sel + slot / 2;
      final barTop = top + h - h * (v / 100) * t;
      final tp = _text(
        '${labels[sel]} - ${v.round()} - ${scoreBandLabel(v)}',
        size: 11,
        weight: FontWeight.bold,
        color: Colors.white,
        maxWidth: size.width - 20,
      );
      const padH = 10.0, padV = 6.0;
      final bw = tp.width + padH * 2;
      final bh = tp.height + padV * 2;
      final bx = (x - bw / 2)
          .clamp(2.0, math.max(2.0, size.width - bw - 2))
          .toDouble();
      final byy = math.max(0.0, barTop - bh - 10);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(bx, byy, bw, bh), const Radius.circular(8)),
        Paint()..color = AppColors.textMain.withValues(alpha: 0.94),
      );
      canvas.drawPath(
        Path()
          ..moveTo(x - 5, byy + bh)
          ..lineTo(x + 5, byy + bh)
          ..lineTo(x, byy + bh + 6)
          ..close(),
        Paint()..color = AppColors.textMain.withValues(alpha: 0.94),
      );
      tp.paint(canvas, Offset(bx + padH, byy + padV));
    }
  }

  @override
  bool shouldRepaint(covariant _BarPainter old) =>
      old.t != t ||
      old.benchmark != benchmark ||
      old.selected != selected ||
      !listEquals(old.values, values) ||
      !listEquals(old.labels, labels);
}

// =============================================================================
// Grouped comparison bars: previous session vs latest, with change badges
// =============================================================================

class ComparisonBarChart extends StatelessWidget {
  final List<String> labels;
  final List<double> before; // 0-100
  final List<double> after; // 0-100
  final double height;

  const ComparisonBarChart({
    super.key,
    required this.labels,
    required this.before,
    required this.after,
    this.height = 250,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: _kChartAnim,
      curve: Curves.easeOutCubic,
      builder: (context, t, _) => SizedBox(
        width: double.infinity,
        height: height,
        child: CustomPaint(
          painter: _ComparisonPainter(labels, before, after, t),
        ),
      ),
    );
  }
}

class _ComparisonPainter extends CustomPainter {
  final List<String> labels;
  final List<double> before;
  final List<double> after;
  final double t;

  _ComparisonPainter(this.labels, this.before, this.after, this.t);

  static const Color beforeColor = Color(0xFFFDE68A); // amber-200

  @override
  void paint(Canvas canvas, Size size) {
    final n = math.min(before.length, after.length);
    if (n == 0) return;
    const left = 28.0, right = 8.0, top = 22.0, bottom = 56.0;
    final w = size.width - left - right;
    final h = size.height - top - bottom;
    if (w <= 0 || h <= 0) return;
    double yOf(double v) => top + h * (1 - v / 100);

    final grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = AppColors.cardBorder;
    for (final v in const [0.0, 25.0, 50.0, 75.0, 100.0]) {
      final y = yOf(v);
      if (v == 0) {
        canvas.drawLine(Offset(left, y), Offset(left + w, y), grid);
      } else {
        _dashedLine(canvas, Offset(left, y), Offset(left + w, y), grid,
            dash: 3, gap: 4);
      }
      final tp = _text('${v.round()}', size: 10, color: AppColors.textMuted, maxWidth: 24);
      tp.paint(canvas, Offset(left - 6 - tp.width, y - tp.height / 2));
    }

    final slot = w / n;
    final barW = math.min(22.0, slot * 0.3);

    void bar(double cx, double v, Color color) {
      final vh = h * (v.clamp(0, 100) / 100) * t;
      final rect = RRect.fromRectAndCorners(
        Rect.fromLTWH(cx - barW / 2, top + h - vh, barW, vh),
        topLeft: const Radius.circular(6),
        topRight: const Radius.circular(6),
      );
      canvas.drawRRect(
        rect,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [color, color.withValues(alpha: 0.7)],
          ).createShader(rect.outerRect),
      );
      final tp = _text('${v.round()}',
          size: 10,
          weight: FontWeight.bold,
          color: AppColors.textMain.withValues(alpha: t.clamp(0.0, 1.0).toDouble()),
          maxWidth: 30);
      _paintCentered(canvas, tp, Offset(cx, top + h - vh - 9));
    }

    for (int i = 0; i < n; i++) {
      final cx = left + slot * i + slot / 2;
      bar(cx - barW / 2 - 2, before[i], beforeColor);
      bar(cx + barW / 2 + 2, after[i], AppColors.primaryAmber);

      final name = _text(labels[i],
          size: 11, weight: FontWeight.w600, color: AppColors.textMain, maxWidth: slot);
      _paintCentered(canvas, name, Offset(cx, top + h + 14));

      // Change badge
      final d = (after[i] - before[i]).round();
      final up = d > 0;
      final flat = d == 0;
      final c = flat
          ? AppColors.textSecondary
          : (up ? AppColors.riskLow : AppColors.riskHigh);
      final label = flat ? '=' : '${up ? '▲' : '▼'} ${d.abs()}';
      final tp = _text(label, size: 10, weight: FontWeight.bold, color: c, maxWidth: slot);
      final pill = Rect.fromCenter(
        center: Offset(cx, top + h + 36),
        width: tp.width + 14,
        height: tp.height + 6,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(pill, const Radius.circular(10)),
        Paint()..color = c.withValues(alpha: 0.14 * t),
      );
      _paintCentered(canvas, tp, pill.center);
    }
  }

  @override
  bool shouldRepaint(covariant _ComparisonPainter old) =>
      old.t != t ||
      !listEquals(old.before, before) ||
      !listEquals(old.after, after) ||
      !listEquals(old.labels, labels);
}

// =============================================================================
// Trend line chart
// =============================================================================

class TrendLineChart extends StatelessWidget {
  final List<String> labels;
  final List<double> values; // 0-100
  final double threshold;
  final Color color;
  final double height;

  const TrendLineChart({
    super.key,
    required this.labels,
    required this.values,
    this.threshold = 75,
    this.color = AppColors.primaryAmber,
    this.height = 210,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: _kChartAnim,
      curve: Curves.easeOutCubic,
      builder: (context, t, _) => SizedBox(
        width: double.infinity,
        height: height,
        child: CustomPaint(
          painter: _TrendPainter(labels, values, threshold, color, t),
        ),
      ),
    );
  }
}

class _TrendPainter extends CustomPainter {
  final List<String> labels;
  final List<double> values;
  final double threshold;
  final Color color;
  final double t;

  _TrendPainter(this.labels, this.values, this.threshold, this.color, this.t);

  Path _smooth(List<Offset> p) {
    final path = Path()..moveTo(p[0].dx, p[0].dy);
    for (int i = 0; i < p.length - 1; i++) {
      final p0 = i == 0 ? p[0] : p[i - 1];
      final p1 = p[i];
      final p2 = p[i + 1];
      final p3 = i + 2 < p.length ? p[i + 2] : p2;
      final c1 = p1 + (p2 - p0) / 6;
      final c2 = p2 - (p3 - p1) / 6;
      path.cubicTo(c1.dx, c1.dy, c2.dx, c2.dy, p2.dx, p2.dy);
    }
    return path;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final n = values.length;
    if (n == 0) return;
    const left = 30.0, right = 14.0, top = 24.0, bottom = 26.0;
    final w = size.width - left - right;
    final h = size.height - top - bottom;
    if (w <= 0 || h <= 0) return;

    final minV = values.reduce(math.min);
    final maxV = values.reduce(math.max);
    double lo = (((math.min(minV, threshold) - 8) / 10).floor() * 10.0)
        .clamp(0.0, 100.0)
        .toDouble();
    double hi = (((math.max(maxV, threshold) + 8) / 10).ceil() * 10.0)
        .clamp(0.0, 100.0)
        .toDouble();
    if (hi - lo < 20) hi = math.min(100, lo + 20);

    double yOf(double v) => top + h * (1 - (v - lo) / (hi - lo));
    double xOf(int i) => n == 1 ? left + w / 2 : left + w * i / (n - 1);

    // Grid + y labels
    final grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = AppColors.cardBorder;
    final step = (hi - lo) <= 40 ? 10.0 : 20.0;
    for (double v = lo; v <= hi + 0.001; v += step) {
      final y = yOf(v);
      _dashedLine(canvas, Offset(left, y), Offset(left + w, y), grid,
          dash: 3, gap: 4);
      final tp = _text('${v.round()}', size: 10, color: AppColors.textMuted, maxWidth: 24);
      tp.paint(canvas, Offset(left - 6 - tp.width, y - tp.height / 2));
    }

    // Low-risk threshold
    final ty = yOf(threshold);
    _dashedLine(
      canvas,
      Offset(left, ty),
      Offset(left + w, ty),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..color = AppColors.riskLow,
    );
    final thLabel = _text('Low risk ${threshold.round()}+',
        size: 10, weight: FontWeight.w600, color: AppColors.riskLow, maxWidth: 90);
    thLabel.paint(canvas, Offset(left + w - thLabel.width, ty - thLabel.height - 2));

    // X labels
    for (int i = 0; i < n && i < labels.length; i++) {
      final tp = _text(labels[i], size: 11, maxWidth: 60);
      final cx = xOf(i).clamp(tp.width / 2, size.width - tp.width / 2).toDouble();
      _paintCentered(canvas, tp, Offset(cx, size.height - bottom / 2 + 2));
    }

    final points = [for (int i = 0; i < n; i++) Offset(xOf(i), yOf(values[i]))];

    if (n > 1) {
      final line = _smooth(points);

      // Gradient area under the curve
      final area = Path.from(line)
        ..lineTo(points.last.dx, top + h)
        ..lineTo(points.first.dx, top + h)
        ..close();
      canvas.drawPath(
        area,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              color.withValues(alpha: 0.30 * t),
              color.withValues(alpha: 0.0),
            ],
          ).createShader(Rect.fromLTWH(left, top, w, h)),
      );

      // Line draws in left-to-right
      final linePaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round
        ..color = color;
      for (final metric in line.computeMetrics()) {
        canvas.drawPath(metric.extractPath(0, metric.length * t), linePaint);
      }
    }

    // Points + value labels
    for (int i = 0; i < n; i++) {
      final p = points[i];
      final double appear = ((t * n) - i).clamp(0.0, 1.0).toDouble();
      if (appear <= 0) continue;
      canvas.drawCircle(p, 7 * appear, Paint()..color = Colors.white);
      canvas.drawCircle(
        p,
        5 * appear,
        Paint()
          ..color = color
          ..style = PaintingStyle.fill,
      );
      final tp = _text('${values[i].round()}',
          size: 11,
          weight: FontWeight.bold,
          color: AppColors.textMain.withValues(alpha: appear));
      final cx = p.dx.clamp(tp.width / 2, size.width - tp.width / 2).toDouble();
      _paintCentered(canvas, tp, Offset(cx, p.dy - 15));
    }
  }

  @override
  bool shouldRepaint(covariant _TrendPainter old) =>
      old.t != t ||
      old.threshold != threshold ||
      old.color != color ||
      !listEquals(old.values, values) ||
      !listEquals(old.labels, labels);
}

// =============================================================================
// Donut chart (also used as a gauge with a single segment)
// =============================================================================

class DonutSegment {
  final double value;
  final Color color;
  const DonutSegment(this.value, this.color);
}

class DonutChart extends StatelessWidget {
  final List<DonutSegment> segments;

  /// Value that represents a full circle. Defaults to the sum of [segments].
  final double? total;
  final double size;
  final double strokeWidth;
  final Widget? center;

  const DonutChart({
    super.key,
    required this.segments,
    this.total,
    this.size = 130,
    this.strokeWidth = 16,
    this.center,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: _kChartAnim,
      curve: Curves.easeOutCubic,
      builder: (context, t, _) => SizedBox(
        width: size,
        height: size,
        child: Stack(
          alignment: Alignment.center,
          children: [
            CustomPaint(
              size: Size.square(size),
              painter: _DonutPainter(segments, total, strokeWidth, t),
            ),
            if (center != null) center!,
          ],
        ),
      ),
    );
  }
}

class _DonutPainter extends CustomPainter {
  final List<DonutSegment> segments;
  final double? total;
  final double strokeWidth;
  final double t;

  _DonutPainter(this.segments, this.total, this.strokeWidth, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = (Offset.zero & size).deflate(strokeWidth / 2);
    final sum = total ?? segments.fold<double>(0, (a, s) => a + s.value);
    if (sum <= 0) return;

    // Track
    canvas.drawArc(
      rect,
      0,
      2 * math.pi,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..color = AppColors.cardBg,
    );

    final single = segments.length == 1;
    final gap = single ? 0.0 : 0.05;
    double start = -math.pi / 2;
    for (final s in segments) {
      if (s.value <= 0) continue;
      final full = s.value / sum * 2 * math.pi * t;
      final sweep = math.max(0.0, full - gap);
      canvas.drawArc(
        rect,
        start + gap / 2,
        sweep,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = strokeWidth
          ..strokeCap = single ? StrokeCap.round : StrokeCap.butt
          ..color = s.color,
      );
      start += full;
    }
  }

  @override
  bool shouldRepaint(covariant _DonutPainter old) =>
      old.t != t ||
      old.total != total ||
      old.strokeWidth != strokeWidth ||
      old.segments != segments;
}


// =============================================================================
// Interactive pie chart (tap a slice or a legend row to pull it out)
// =============================================================================

/// Distinct, non-risk colours for categorical charts (so they don't get
/// confused with the green/amber/red risk colours).
const List<Color> kChartPalette = [
  Color(0xFFF59E0B), // amber
  Color(0xFF6366F1), // indigo
  Color(0xFF14B8A6), // teal
  Color(0xFFF43F5E), // rose
  Color(0xFF0EA5E9), // sky
];

class PieSlice {
  final String label;
  final double value;
  final Color color;
  const PieSlice(this.label, this.value, this.color);
}

class InteractivePieChart extends StatefulWidget {
  final List<PieSlice> slices;
  final double size;

  /// 0 = full pie. Values like 0.5 turn it into a donut.
  final double holeRatio;
  final String unit;

  const InteractivePieChart({
    super.key,
    required this.slices,
    this.size = 150,
    this.holeRatio = 0,
    this.unit = '',
  });

  @override
  State<InteractivePieChart> createState() => _InteractivePieChartState();
}

class _InteractivePieChartState extends State<InteractivePieChart>
    with TickerProviderStateMixin {
  late final AnimationController _intro =
      AnimationController(vsync: this, duration: _kChartAnim)..forward();
  late final AnimationController _pop =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 260));
  int? _selected;

  double get _total =>
      widget.slices.fold<double>(0, (a, s) => a + math.max(0, s.value));

  @override
  void dispose() {
    _intro.dispose();
    _pop.dispose();
    super.dispose();
  }

  void _select(int? i) {
    setState(() => _selected = i);
    if (i != null) _pop.forward(from: 0);
  }

  void _onTap(Offset p) {
    final total = _total;
    if (total <= 0) return;
    final c = Offset(widget.size / 2, widget.size / 2);
    final d = p - c;
    final maxR = widget.size / 2 - 12;
    if (d.distance > maxR + 12 || d.distance < maxR * widget.holeRatio) {
      _select(null);
      return;
    }
    var ang = math.atan2(d.dy, d.dx) + math.pi / 2; // 0 at 12 o'clock, clockwise
    if (ang < 0) ang += 2 * math.pi;
    double acc = 0;
    for (int i = 0; i < widget.slices.length; i++) {
      final sweep = math.max(0, widget.slices[i].value) / total * 2 * math.pi;
      if (ang >= acc && ang < acc + sweep) {
        _select(_selected == i ? null : i);
        return;
      }
      acc += sweep;
    }
  }

  String _fmt(double v) =>
      v == v.roundToDouble() ? '${v.round()}' : v.toStringAsFixed(1);

  @override
  Widget build(BuildContext context) {
    final total = _total;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        AnimatedBuilder(
          animation: Listenable.merge([_intro, _pop]),
          builder: (context, _) => GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: (d) => _onTap(d.localPosition),
            child: SizedBox(
              width: widget.size,
              height: widget.size,
              child: CustomPaint(
                painter: _PiePainter(
                  widget.slices,
                  widget.holeRatio,
                  Curves.easeOutCubic.transform(_intro.value),
                  _selected,
                  Curves.easeOutCubic.transform(_pop.value),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            children: [
              for (int i = 0; i < widget.slices.length; i++)
                _legendRow(i, total),
            ],
          ),
        ),
      ],
    );
  }

  Widget _legendRow(int i, double total) {
    final s = widget.slices[i];
    final selected = _selected == i;
    final pct = total > 0 ? s.value / total * 100 : 0;
    return GestureDetector(
      onTap: s.value > 0 ? () => _select(selected ? null : i) : null,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(vertical: 2),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? s.color.withValues(alpha: 0.13) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected ? s.color.withValues(alpha: 0.6) : Colors.transparent,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                color: s.color,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                s.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: selected ? FontWeight.bold : FontWeight.w500,
                  color: AppColors.textMain,
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  widget.unit.isEmpty ? _fmt(s.value) : '${_fmt(s.value)} ${widget.unit}',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textMain,
                  ),
                ),
                Text('${pct.round()}%', style: TailwindTheme.caption),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _PiePainter extends CustomPainter {
  final List<PieSlice> slices;
  final double holeRatio;
  final double intro;
  final int? selected;
  final double pop;

  _PiePainter(this.slices, this.holeRatio, this.intro, this.selected, this.pop);

  @override
  void paint(Canvas canvas, Size size) {
    final total = slices.fold<double>(0, (a, s) => a + math.max(0, s.value));
    if (total <= 0) return;
    final center = size.center(Offset.zero);
    final r = math.min(size.width, size.height) / 2 - 12;
    if (r <= 0) return;
    final rIn = r * holeRatio;

    double start = -math.pi / 2;
    for (int i = 0; i < slices.length; i++) {
      final v = math.max(0, slices[i].value).toDouble();
      if (v <= 0) continue;
      final sweep = v / total * 2 * math.pi * intro;
      final mid = start + sweep / 2;
      final isSel = selected == i;
      final dim = selected != null && !isSel;
      final off = isSel
          ? Offset(math.cos(mid), math.sin(mid)) * (11 * pop)
          : Offset.zero;
      final c = center + off;

      final path = Path();
      if (rIn > 0) {
        path.arcTo(Rect.fromCircle(center: c, radius: r), start, sweep, true);
        path.arcTo(Rect.fromCircle(center: c, radius: rIn), start + sweep, -sweep, false);
      } else {
        path.moveTo(c.dx, c.dy);
        path.arcTo(Rect.fromCircle(center: c, radius: r), start, sweep, false);
      }
      path.close();

      if (isSel) {
        canvas.drawShadow(path, Colors.black.withValues(alpha: 0.4), 7 * pop, false);
      }
      canvas.drawPath(
        path,
        Paint()..color = slices[i].color.withValues(alpha: dim ? 0.5 : 1.0),
      );
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..strokeJoin = StrokeJoin.round
          ..color = Colors.white,
      );

      // Percentage inside the slice
      final frac = v / total;
      if (frac >= 0.08 && intro > 0.9) {
        final labelR = rIn > 0 ? (r + rIn) / 2 : r * 0.62;
        final tp = _text('${(frac * 100).round()}%',
            size: 12, weight: FontWeight.bold, color: Colors.white, maxWidth: 40);
        _paintCentered(canvas, tp, c + Offset(math.cos(mid), math.sin(mid)) * labelR);
      }

      start += v / total * 2 * math.pi * intro;
    }
  }

  @override
  bool shouldRepaint(covariant _PiePainter old) =>
      old.intro != intro ||
      old.pop != pop ||
      old.selected != selected ||
      old.holeRatio != holeRatio ||
      old.slices != slices;
}
