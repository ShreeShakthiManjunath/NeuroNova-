import 'package:flutter/material.dart';

class AppConstants {
  // Universal Layout Padding
  static const EdgeInsets screenPadding = EdgeInsets.all(20.0);
  static const EdgeInsets horizontalPadding = EdgeInsets.symmetric(horizontal: 24.0);
  
  // Precision Component Radii
  static const double cardRadius = 24.0;
  static const double buttonRadius = 12.0;
  static const double inputRadius = 12.0;
  
  // Simulated System States (From Mockup Data)
  static const int baselineHealthScore = 62;
  static const String overallRiskStatus = "Moderate Risk";
}