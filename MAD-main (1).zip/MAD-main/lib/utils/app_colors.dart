import 'package:flutter/material.dart';

/// App-wide color palette built around dynamic warm yellow, amber, and golden shades.
class AppColors {
  // Canvas & Surface Backgrounds (Light Theme Shades of Yellow / Amber)
  static const Color background = Color(0xFFFFFDF5); // Tailwind Amber 50
  static const Color surface = Color(0xFFFFFBEB);    // Soft warm cream
  static const Color cardBg = Color(0xFFFEF3C7);     // Amber 100 card highlight
  static const Color cardBorder = Color(0xFFFDE68A); // Amber 200 border

  // Primary Brand Colors (Golden Amber / Warm Gold)
  static const Color primaryAmber = Color(0xFFD97706); // Amber 600
  static const Color primaryGold = Color(0xFFF59E0B);  // Amber 500
  static const Color primaryDark = Color(0xFFB45309);  // Amber 700
  static const Color primaryBlue = Color(0xFFD97706);  // Backward compatibility alias

  // Text Hierarchy
  static const Color textMain = Color(0xFF0F172A);      // Slate 900
  static const Color textSecondary = Color(0xFF475569); // Slate 600
  static const Color textMuted = Color(0xFF78350F);     // Amber 900

  // Dynamic Risk States Matrix
  static const Color riskHigh = Color(0xFFDC2626);     // Red 600
  static const Color riskModerate = Color(0xFFD97706); // Amber 600
  static const Color riskLow = Color(0xFF16A34A);      // Green 600
}