/// Single source of truth for the screening numbers shown in analysis charts,
/// so the Overview, Daily Progress and chart widgets never disagree.
///
/// Replace these with real values from SQLite (`DatabaseHelper`) when ready.
class TestScore {
  final String name;
  final String shortName;
  final double score; // 0-100, higher is better

  const TestScore(this.name, this.shortName, this.score);
}

class ScreeningData {
  static const List<TestScore> todayScores = [
    TestScore('Voice Assessment', 'Voice', 78),
    TestScore('Sequence Memory', 'Memory', 72),
    TestScore('Hand Tremor', 'Tremor', 68),
    TestScore('Finger Tapping', 'Tapping', 70),
    TestScore('Postural Balance', 'Balance', 65),
  ];

  static List<String> get shortNames =>
      todayScores.map((t) => t.shortName).toList();

  static List<double> get scores => todayScores.map((t) => t.score).toList();

  static double get average =>
      scores.reduce((a, b) => a + b) / todayScores.length;

  /// Dates of the screening sessions on the trend chart.
  static const List<String> trendLabels = ['6 Jul', '10 Jul', '15 Jul', '21 Jul'];

  /// Per-test score history (same order as [trendLabels]).
  /// The last value of each series equals today's score above.
  static const Map<String, List<double>> trendBySeries = {
    'Voice': [70, 72, 75, 78],
    'Memory': [60, 66, 68, 72],
    'Tremor': [55, 60, 58, 68],
    'Tapping': [58, 64, 62, 70],
    'Balance': [52, 58, 57, 65],
  };

  /// Overall trend = average of all tests at each session.
  static List<double> get trendOverall {
    final series = trendBySeries.values.toList();
    return List<double>.generate(trendLabels.length, (i) {
      final sum = series.fold<double>(0, (acc, s) => acc + s[i]);
      return sum / series.length;
    });
  }
}
