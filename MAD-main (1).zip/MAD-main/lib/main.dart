import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';

import 'firebase_options.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/registration_screen.dart';
import 'screens/home_screen.dart';
import 'screens/connect_cube_screen.dart';
import 'screens/device_status_screen.dart';
import 'screens/symptom_screen.dart';
import 'screens/voice_test_screen.dart';
import 'screens/memory_test_screen.dart';
import 'screens/hardware_tests_screen.dart';
import 'screens/hardware_progress_screen.dart';
import 'screens/test_results_overview_screen.dart';
import 'screens/ai_analysis_screen.dart';
import 'screens/neurological_risk_report_screen.dart';
import 'screens/analysis_3d_screen.dart';
import 'screens/daily_progress_screen.dart';
import 'screens/doctor_screen.dart';
import 'screens/history_screen.dart';
import 'screens/emergency_sos_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/neuronova_assistant_screen.dart';
import 'utils/app_colors.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    ).timeout(const Duration(seconds: 2));
  } catch (e) {
    debugPrint('Firebase init fallback: $e');
  }

  runApp(const NeuroNovaApp());
}

class NeuroNovaApp extends StatelessWidget {
  const NeuroNovaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NeuroNova',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primaryAmber,
          surface: AppColors.background,
        ),
        fontFamily: 'Roboto',
      ),
      home: const SplashScreen(),
      routes: {
        '/splash': (context) => const SplashScreen(),
        '/login': (context) => const LoginScreen(),
        '/register': (context) => const RegistrationScreen(),
        '/home': (context) => const HomeScreen(),
        '/connect_cube': (context) => const ConnectCubeScreen(),
        '/device_status': (context) => const DeviceStatusScreen(),
        '/symptom': (context) => const SymptomScreen(),
        '/voice_test': (context) => const VoiceTestScreen(),
        '/memory_test': (context) => const MemoryTestScreen(),
        '/hardware_tests': (context) => const HardwareTestsScreen(),
        '/hardware_progress': (context) => const HardwareProgressScreen(),
        '/test_results_overview': (context) => const TestResultsOverviewScreen(),
        '/ai_analysis': (context) => const AiAnalysisScreen(),
        '/risk_report': (context) => const NeurologicalRiskReportScreen(),
        '/analysis_3d': (context) => const Analysis3dScreen(),
        '/daily_progress': (context) => const DailyProgressScreen(),
        '/doctor': (context) => const DoctorScreen(),
        '/history': (context) => const HistoryScreen(),
        '/emergency_sos': (context) => const EmergencySosScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/assistant': (context) => const NeuroNovaAssistantScreen(),
      },
    );
  }
}