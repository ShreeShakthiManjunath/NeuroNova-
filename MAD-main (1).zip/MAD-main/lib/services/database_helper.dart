import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    try {
      final dbPath = await getDatabasesPath();
      final path = join(dbPath, 'neuronova.db');

      return await openDatabase(
        path,
        version: 1,
        onCreate: _onCreate,
      );
    } on MissingPluginException catch (e) {
      debugPrint('sqflite MissingPluginException (App restart needed): $e');
      return await openDatabase(
        inMemoryDatabasePath,
        version: 1,
        onCreate: _onCreate,
      );
    } catch (e) {
      debugPrint('Database init fallback: $e');
      return await openDatabase(
        inMemoryDatabasePath,
        version: 1,
        onCreate: _onCreate,
      );
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        age INTEGER,
        medical_notes TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE test_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_email TEXT NOT NULL,
        test_type TEXT NOT NULL,
        score INTEGER NOT NULL,
        risk_level TEXT NOT NULL,
        ai_summary TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');
  }

  String _hashPassword(String password) {
    final bytes = utf8.encode(password);
    return sha256.convert(bytes).toString();
  }

  /// Check if SQLite database has any registered users
  Future<bool> hasRegisteredUsers() async {
    try {
      final db = await database;
      final count = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM users'),
      );
      return (count ?? 0) > 0;
    } catch (e) {
      return false;
    }
  }

  /// Register new user in SQLite DB
  Future<bool> registerUser({
    required String name,
    required String email,
    required String password,
    int? age,
    String? medicalNotes,
  }) async {
    final db = await database;
    try {
      final passwordHash = _hashPassword(password);
      await db.insert(
        'users',
        {
          'name': name,
          'email': email.trim().toLowerCase(),
          'password_hash': passwordHash,
          'age': age ?? 30,
          'medical_notes': medicalNotes ?? '',
          'created_at': DateTime.now().toIso8601String(),
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      return true;
    } catch (e) {
      debugPrint('SQLite Register error: $e');
      return false;
    }
  }

  /// Validate Email & Password against SQLite DB
  Future<Map<String, dynamic>?> loginUser({
    required String email,
    required String password,
  }) async {
    final db = await database;
    final passwordHash = _hashPassword(password);
    final results = await db.query(
      'users',
      where: 'email = ? AND password_hash = ?',
      whereArgs: [email.trim().toLowerCase(), passwordHash],
    );

    if (results.isNotEmpty) {
      return results.first;
    }
    return null;
  }

  /// Find user by email
  Future<Map<String, dynamic>?> getUserByEmail(String email) async {
    final db = await database;
    final results = await db.query(
      'users',
      where: 'email = ?',
      whereArgs: [email.trim().toLowerCase()],
    );

    if (results.isNotEmpty) {
      return results.first;
    }
    return null;
  }

  /// Ensure user exists for OAuth logins
  Future<Map<String, dynamic>> ensureOAuthUser({
    required String name,
    required String email,
  }) async {
    final existing = await getUserByEmail(email);
    if (existing != null) return existing;

    final db = await database;
    final passwordHash = _hashPassword('OAUTH_GOOGLE_PROTECTED');
    await db.insert(
      'users',
      {
        'name': name,
        'email': email.trim().toLowerCase(),
        'password_hash': passwordHash,
        'age': 25,
        'medical_notes': 'Google OAuth Authenticated',
        'created_at': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );

    return (await getUserByEmail(email))!;
  }

  /// Save test result to SQLite
  Future<void> saveTestRecord({
    required String userEmail,
    required String testType,
    required int score,
    required String riskLevel,
    required String aiSummary,
  }) async {
    final db = await database;
    await db.insert('test_records', {
      'user_email': userEmail,
      'test_type': testType,
      'score': score,
      'risk_level': riskLevel,
      'ai_summary': aiSummary,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  /// Get test records for user
  Future<List<Map<String, dynamic>>> getTestRecords(String userEmail) async {
    final db = await database;
    return await db.query(
      'test_records',
      where: 'user_email = ?',
      whereArgs: [userEmail],
      orderBy: 'id DESC',
    );
  }
}
