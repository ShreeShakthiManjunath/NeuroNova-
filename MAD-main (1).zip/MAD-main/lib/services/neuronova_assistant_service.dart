import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

/// A reply from the NeuroNova Assistant. [route] / [routeLabel] are optional
/// and let the chat UI show a one-tap button that opens the relevant screen.
class AssistantReply {
  final String text;
  final String? route;
  final String? routeLabel;

  const AssistantReply(this.text, {this.route, this.routeLabel});
}

/// Project-aware chatbot for NeuroNova.
///
/// * With a Gemini key (`--dart-define=GEMINI_API_KEY=...`) it answers using
///   Gemini, primed with what NeuroNova is and which screens exist.
/// * Without a key (or if the call fails) it falls back to a built-in
///   knowledge base, so the assistant always works offline.
class NeuroNovaAssistantService {
  static const String assistantName = 'NeuroNova Assistant';

  /// Override with `--dart-define=GEMINI_MODEL=...` if Google retires a model.
  static const String _model =
      String.fromEnvironment('GEMINI_MODEL', defaultValue: 'gemini-2.5-flash');

  final String _apiKey;

  NeuroNovaAssistantService({String? apiKey})
      : _apiKey = apiKey ??
            const String.fromEnvironment('GEMINI_API_KEY', defaultValue: '');

  /// Screens the assistant is allowed to link to (route -> button label).
  static const Map<String, String> routes = {
    '/voice_test': 'Open Voice Test',
    '/memory_test': 'Open Memory Test',
    '/symptom': 'Open Symptom Screener',
    '/analysis_3d': 'Open 3D Body Map',
    '/connect_cube': 'Connect Neuro Cube',
    '/hardware_tests': 'Open Hardware Suite',
    '/device_status': 'Check Device Status',
    '/risk_report': 'View Risk Report',
    '/ai_analysis': 'Open AI Analysis',
    '/daily_progress': 'View Daily Progress',
    '/history': 'View History',
    '/doctor': 'Doctor & Hospital',
    '/emergency_sos': 'Open Emergency SOS',
    '/profile': 'Open Profile',
  };

  static final RegExp _routeTag = RegExp(r'\[\[open:(/[a-z_0-9]+)\]\]');

  String get _systemPrompt => '''
You are "$assistantName", the in-app helper for NeuroNova, a Flutter mobile health (mHealth) app for early neurological SCREENING (not diagnosis).

What NeuroNova does:
- Voice Test: reads a phrase aloud; measures vocal micro-tremor and pitch stability.
- Memory Test: sequence-recall game for cognitive recall and reaction time.
- Symptom Screener: 4 adaptive questions (tremor, memory, balance, speech) ending in a short summary.
- Neuro Cube / Hardware Suite: Bluetooth wearable IMU sensors (wrist, lumbar, ankle) for hand tremor, finger tapping and balance sway.
- 3D Body Map: rotatable anatomical body with heatmaps; tap a joint to see frequency (Hz) and sway angle.
- AI Analysis, Risk Report, Daily Progress, History: scores out of 100 and risk levels (Low >= 75, Moderate 60-74, High < 60), trends and saved results.
- Doctor & Hospital, Emergency SOS: physician contacts and one-tap caregiver alert.

Routes you may point to: ${routes.keys.join(', ')}.
When a screen would help, end your reply with exactly one tag like [[open:/voice_test]] (only routes from that list).

Rules:
- Be warm, concise (2-5 sentences), and use plain language.
- NeuroNova is a screening aid. Never give a definitive diagnosis or medication advice; encourage seeing a neurologist when appropriate.
- If the user describes an emergency (sudden face drooping, arm weakness, slurred speech, severe headache, chest pain, trouble breathing, loss of consciousness, thoughts of self-harm), tell them to call their local emergency number now and add [[open:/emergency_sos]].
- Stay on topic: NeuroNova, its tests and results, and general brain-health habits. Politely decline unrelated requests.
''';

  /// Ask the assistant. [history] holds earlier turns as
  /// `{'sender': 'user'|'assistant', 'text': ...}` (excluding [userMessage]).
  Future<AssistantReply> ask({
    required String userMessage,
    List<Map<String, String>> history = const [],
    Map<String, dynamic> context = const {},
  }) async {
    // Safety first: emergencies never wait on the network.
    if (_looksLikeEmergency(userMessage)) {
      return _emergencyReply;
    }

    if (_apiKey.isNotEmpty) {
      try {
        final model = GenerativeModel(
          model: _model,
          apiKey: _apiKey,
          systemInstruction: Content.system(_systemPrompt),
        );

        final recent = history.length > 12
            ? history.sublist(history.length - 12)
            : history;
        final past = <Content>[
          for (final m in recent)
            if (m['sender'] == 'user')
              Content.text(m['text'] ?? '')
            else
              Content.model([TextPart(m['text'] ?? '')]),
        ];

        final chat = model.startChat(history: past);
        final scoreNote = context.isEmpty
            ? ''
            : '\n\n(Latest screening snapshot: ${_describe(context)})';
        final response = await chat
            .sendMessage(Content.text('$userMessage$scoreNote'))
            .timeout(const Duration(seconds: 20));

        final raw = response.text?.trim() ?? '';
        if (raw.isNotEmpty) return _parse(raw);
      } catch (e) {
        debugPrint('NeuroNova Assistant Gemini fallback: $e');
      }
    }

    return _offlineReply(userMessage, context);
  }

  // ---------------------------------------------------------------------------
  // Parsing helpers
  // ---------------------------------------------------------------------------

  AssistantReply _parse(String raw) {
    final match = _routeTag.firstMatch(raw);
    final route = match?.group(1);
    final text = raw.replaceAll(_routeTag, '').trim();
    if (route != null && routes.containsKey(route)) {
      return AssistantReply(text, route: route, routeLabel: routes[route]);
    }
    return AssistantReply(text);
  }

  String _describe(Map<String, dynamic> c) {
    final parts = <String>[];
    if (c['overallScore'] != null) parts.add('overall ${c['overallScore']}/100');
    if (c['riskLevel'] != null) parts.add('${c['riskLevel']}');
    if (c['voiceScore'] != null) parts.add('voice ${c['voiceScore']}');
    if (c['memoryScore'] != null) parts.add('memory ${c['memoryScore']}');
    if (c['handTremorScore'] != null) parts.add('hand tremor ${c['handTremorScore']}');
    if (c['fingerTappingScore'] != null) parts.add('finger tapping ${c['fingerTappingScore']}');
    if (c['balanceScore'] != null) parts.add('balance ${c['balanceScore']}');
    return parts.join(', ');
  }

  // ---------------------------------------------------------------------------
  // Emergency handling
  // ---------------------------------------------------------------------------

  static const List<String> _emergencyWords = [
    'face drooping',
    'face is drooping',
    'can\'t move my arm',
    'cannot move my arm',
    'sudden weakness',
    'slurred speech suddenly',
    'worst headache',
    'chest pain',
    'can\'t breathe',
    'cannot breathe',
    'passed out',
    'unconscious',
    'seizure',
    'stroke',
    'suicide',
    'kill myself',
    'end my life',
    'self harm',
    'self-harm',
  ];

  bool _looksLikeEmergency(String message) {
    final m = message.toLowerCase();
    return _emergencyWords.any(m.contains);
  }

  static const AssistantReply _emergencyReply = AssistantReply(
    'This could be serious. Please call your local emergency number or go to '
    'the nearest emergency room right now - do not wait for a screening result. '
    'If someone is with you, ask them to stay with you. You can also alert your '
    'caregivers from the Emergency SOS screen.',
    route: '/emergency_sos',
    routeLabel: 'Open Emergency SOS',
  );

  // ---------------------------------------------------------------------------
  // Offline knowledge base
  // ---------------------------------------------------------------------------

  AssistantReply _offlineReply(String message, Map<String, dynamic> ctx) {
    final m = message.toLowerCase();

    for (final topic in _topics) {
      if (topic.keywords.any((k) => _matches(m, k))) {
        var text = topic.answer;
        if (topic.usesScore) {
          final overall = ctx['overallScore'] ?? 62;
          final risk = ctx['riskLevel'] ?? 'Moderate Risk';
          text = text
              .replaceAll('{score}', '$overall')
              .replaceAll('{risk}', '$risk');
        }
        return AssistantReply(
          text,
          route: topic.route,
          routeLabel: topic.route == null ? null : routes[topic.route],
        );
      }
    }

    return const AssistantReply(
      'I\'m the NeuroNova Assistant. I can explain the Voice, Memory and '
      'Symptom tests, the 3D Body Map, your scores and risk level, the Neuro '
      'Cube sensors, and how to reach a doctor or caregiver. What would you '
      'like to know?',
    );
  }

  /// Word-start match so "hey" doesn't fire on "they" or "data" on "update".
  /// A trailing `$` means the keyword must be a whole word (e.g. `hi$`).
  static bool _matches(String text, String keyword) {
    final whole = keyword.endsWith(r'$');
    final word = whole ? keyword.substring(0, keyword.length - 1) : keyword;
    final pattern = '\\b${RegExp.escape(word)}${whole ? '\\b' : ''}';
    return RegExp(pattern).hasMatch(text);
  }

  static final List<_Topic> _topics = [
    _Topic(
      keywords: [r'hello$', r'hi$', r'hey$', 'good morning', 'good evening', 'who are you', 'your name'],
      answer:
          'Hi! I\'m the NeuroNova Assistant - your guide to this app. I can walk you through the tests, explain your results, and take you to the right screen. What would you like to do?',
    ),
    _Topic(
      keywords: ['what can you do', 'features', 'what is neuronova', 'about the app', 'about neuronova'],
      answer:
          'NeuroNova is a neurological screening app. It checks your voice for micro-tremors, tests memory recall, asks adaptive symptom questions, reads wearable sensors for tremor and balance, and shows everything on a 3D body map with a risk report. It supports screening - it doesn\'t replace a doctor.',
    ),
    _Topic(
      keywords: ['voice', 'speech test', 'pitch', 'vocal'],
      answer:
          'The Voice Test records you reading a short phrase and measures vocal micro-tremor and pitch stability. Find a quiet spot, hold the phone about a hand-span from your mouth, and speak at your normal volume.',
      route: '/voice_test',
    ),
    _Topic(
      keywords: ['memory', 'sequence', 'recall', 'remember'],
      answer:
          'The Memory Test shows a sequence you then repeat; it gets longer each level. It tracks recall accuracy and reaction time, and repeating it regularly shows your trend.',
      route: '/memory_test',
    ),
    _Topic(
      keywords: ['symptom', 'screener', 'questionnaire', 'questions'],
      answer:
          'The Symptom Screener asks 4 adaptive questions about tremor, memory, balance or speech, then gives a short summary with a risk level and suggested next steps.',
      route: '/symptom',
    ),
    _Topic(
      keywords: ['3d', 'body map', 'heatmap', 'anatomical', 'joint', 'rotate'],
      answer:
          'The 3D Body Map shows a rotatable body with color-coded heatmaps (red = high tremor, amber = moderate, green = stable). Drag to rotate, switch front/back, and tap a joint to see its frequency (Hz) and sway angle.',
      route: '/analysis_3d',
    ),
    _Topic(
      keywords: ['cube', 'bluetooth', 'pair', 'sensor', 'wearable', 'imu', 'device', 'battery'],
      answer:
          'The Neuro Cube sensors (wrist, lumbar, ankle) pair over Bluetooth. Turn Bluetooth on, keep the sensors close, then connect from the Connect screen. Device Status shows connection and battery.',
      route: '/connect_cube',
    ),
    _Topic(
      keywords: ['hardware', 'finger tapping', 'tapping', 'hand tremor', 'balance'],
      answer:
          'The Hardware Suite uses the wearable sensors for hand tremor, finger tapping and balance sway. Each test produces a score out of 100 that feeds your overall result.',
      route: '/hardware_tests',
    ),
    _Topic(
      keywords: ['score', 'mean', 'risk', 'result', 'report', 'low risk', 'moderate', 'high risk'],
      answer:
          'Your overall score is {score}/100, shown as "{risk}". Scores of 75+ are Low Risk, 60-74 Moderate, and below 60 High. It blends voice, memory, tremor, tapping and balance. It\'s a screening indicator, not a diagnosis - if you\'re worried, share the report with a neurologist.',
      route: '/risk_report',
      usesScore: true,
    ),
    _Topic(
      keywords: ['progress', 'trend', 'daily', 'improv', 'track'],
      answer:
          'Daily Progress charts your scores over time so you can see whether things are steady or changing. Testing at the same time each day gives the most comparable results.',
      route: '/daily_progress',
    ),
    _Topic(
      keywords: ['history', 'past tests', 'previous', 'records', 'saved'],
      answer:
          'History lists every saved screening on your device, so you can compare earlier results with new ones.',
      route: '/history',
    ),
    _Topic(
      keywords: ['doctor', 'neurologist', 'hospital', 'consult', 'appointment', 'physician'],
      answer:
          'If your result is Moderate or High Risk, or you notice new or worsening symptoms, it\'s sensible to see a neurologist. The Doctor screen has physician and hospital details and a report you can share.',
      route: '/doctor',
    ),
    _Topic(
      keywords: ['sos', 'caregiver', 'emergency', 'alert'],
      answer:
          'Emergency SOS sends a distress alert to your registered caregivers in one tap and lists emergency contacts. For a medical emergency, always call your local emergency number first.',
      route: '/emergency_sos',
    ),
    _Topic(
      keywords: ['profile', 'account', 'login', 'password', 'logout', 'sign out', 'register'],
      answer:
          'You can view and manage your account details from the Profile screen.',
      route: '/profile',
    ),
    _Topic(
      keywords: ['privacy', 'my data', 'secure', 'stored'],
      answer:
          'Your screening records are stored locally on your device in a SQLite database, and sign-in uses Firebase Authentication. AI chat features only send what\'s needed to Gemini when an API key is configured.',
    ),
    _Topic(
      keywords: ['exercise', 'diet', 'food', 'sleep', 'lifestyle', 'brain health', 'lower tremor', 'reduce'],
      answer:
          'Habits that support brain health: regular aerobic exercise (about 30 minutes most days), 7-8 hours of sleep, a Mediterranean-style diet rich in leafy greens, berries and omega-3s, staying socially and mentally active, and managing stress and caffeine if tremors bother you.',
    ),
    _Topic(
      keywords: ['thank', r'bye$'],
      answer: 'You\'re welcome! I\'m here whenever you need me.',
    ),
  ];
}

class _Topic {
  final List<String> keywords;
  final String answer;
  final String? route;
  final bool usesScore;

  const _Topic({
    required this.keywords,
    required this.answer,
    this.route,
    this.usesScore = false,
  });
}
