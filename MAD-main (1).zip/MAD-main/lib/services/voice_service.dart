class MemoryService {
  final List<int> _targetSequence = [3, 7, 1, 9, 4]; // Matches the UI blueprint sequence exactly
  
  List<int> get targetSequence => _targetSequence;

  bool verifyUserSequence(List<int> inputSequence) {
    if (inputSequence.length != _targetSequence.length) return false;
    
    for (int i = 0; i < _targetSequence.length; i++) {
      if (inputSequence[i] != _targetSequence[i]) return false;
    }
    return true;
  }
}