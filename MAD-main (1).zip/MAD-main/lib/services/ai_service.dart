import 'dart:async';

class AiService {
  // Streams processing steps back to the UI view model
  Stream<String> runNeurologicalAnalysis() async* {
    yield "Analyzing your responses...";
    await Future.delayed(const Duration(seconds: 2));
    
    yield "Processing Test Results ✔";
    await Future.delayed(const Duration(seconds: 2));
    
    yield "Comparing with AI Model ✔";
    await Future.delayed(const Duration(seconds: 2));
    
    yield "Generating Risk Report...";
    await Future.delayed(const Duration(seconds: 1500));
  }

  Map<String, dynamic> fetchMockAnalysisReport() {
    return {
      "overallScore": 62,
      "riskLevel": "Moderate Risk",
      "voiceScore": 78,
      "memoryScore": 72,
      "handTremorScore": 68,
      "fingerTappingScore": 70,
      "balanceScore": 65
    };
  }
}