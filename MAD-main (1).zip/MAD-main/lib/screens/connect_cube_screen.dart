import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class ConnectCubeScreen extends StatelessWidget {
  const ConnectCubeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Connect Hardware', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight - 32),
                child: IntrinsicHeight(
                  child: Column(
                    children: [
                      const Align(
                        alignment: Alignment.center,
                        child: Text(
                          'Connect\nSmart Neuro Cube',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppColors.textMain),
                        ),
                      ),
                      const SizedBox(height: 24),
                      CircleAvatar(
                        radius: 54,
                        backgroundColor: AppColors.primaryBlue.withValues(alpha: 0.1),
                        child: const Icon(Icons.bluetooth, size: 54, color: AppColors.primaryBlue),
                      ),
                      const SizedBox(height: 24),
                      const Align(
                        alignment: Alignment.centerLeft,
                        child: Text('Available Devices', style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.bold)),
                      ),
                      const SizedBox(height: 12),
                      _deviceRow('Neuro Cube_01A7', 'Connected', AppColors.riskLow),
                      _deviceRow('Neuro Cube_02B3', 'Not Paired', AppColors.textSecondary),
                      const Spacer(),
                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          style: TailwindTheme.primaryButtonStyle,
                          onPressed: () => Navigator.pushNamed(context, '/device_status'),
                          child: const Text('SCAN AGAIN', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _deviceRow(String name, String status, Color statusColor) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Row(
        children: [
          const Icon(Icons.developer_board, color: AppColors.primaryBlue),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(color: AppColors.textMain, fontWeight: FontWeight.bold)),
                Text(status, style: TextStyle(color: statusColor, fontSize: 12)),
              ],
            ),
          ),
          const Icon(Icons.signal_cellular_alt, color: AppColors.textSecondary, size: 18),
        ],
      ),
    );
  }
}