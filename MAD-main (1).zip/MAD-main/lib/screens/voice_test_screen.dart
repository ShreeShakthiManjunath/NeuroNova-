import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class VoiceTestScreen extends StatefulWidget {
  const VoiceTestScreen({super.key});

  @override
  State<VoiceTestScreen> createState() => _VoiceTestScreenState();
}

class _VoiceTestScreenState extends State<VoiceTestScreen>
    with SingleTickerProviderStateMixin {
  bool _isRecording = false;
  bool _isFinished = false;
  int _secondsRemaining = 5;
  Timer? _timer;

  late AnimationController _animController;
  final Random _random = Random();
  List<double> _waveformHeights = List.generate(20, (_) => 10.0);

  // Computed acoustic metrics
  double _tremorIndex = 0.28;
  double _pitchStability = 94.2;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    )..addListener(() {
        if (_isRecording) {
          setState(() {
            _waveformHeights = List.generate(
              20,
              (_) => 10.0 + _random.nextDouble() * 50.0,
            );
          });
        }
      });
  }

  void _startRecording() {
    setState(() {
      _isRecording = true;
      _isFinished = false;
      _secondsRemaining = 5;
    });
    _animController.repeat(reverse: true);

    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_secondsRemaining > 1) {
        setState(() => _secondsRemaining--);
      } else {
        _stopRecording();
      }
    });
  }

  void _stopRecording() {
    _timer?.cancel();
    _animController.stop();
    setState(() {
      _isRecording = false;
      _isFinished = true;
      _waveformHeights = List.generate(20, (_) => 12.0);
      _tremorIndex = 0.20 + _random.nextDouble() * 0.25;
      _pitchStability = 88.0 + _random.nextDouble() * 10.0;
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Voice Acoustic Test', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight - 48),
                child: IntrinsicHeight(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text(
                        'Vocal Stability Assessment',
                        style: TailwindTheme.h2,
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Press record and speak the phrase below clearly into your microphone.',
                        textAlign: TextAlign.center,
                        style: TailwindTheme.body,
                      ),
                      const SizedBox(height: 24),

                      // Speech Prompt Card
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(20),
                        decoration: TailwindTheme.cardDecoration(),
                        child: Column(
                          children: const [
                            Text(
                              'PROMPT PHRASE',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primaryAmber,
                                letterSpacing: 1.2,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              '"The quick brown fox jumps over the lazy dog and sustains the AAAA sound."',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textMain,
                                height: 1.4,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Waveform Visualizer
                      Container(
                        height: 80,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: _waveformHeights.map((h) {
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 100),
                              width: 6,
                              height: h,
                              margin: const EdgeInsets.symmetric(horizontal: 3),
                              decoration: BoxDecoration(
                                color: _isRecording
                                    ? AppColors.primaryAmber
                                    : AppColors.cardBorder,
                                borderRadius: BorderRadius.circular(3),
                              ),
                            );
                          }).toList(),
                        ),
                      ),

                      const SizedBox(height: 16),

                      // Timer / Status Text
                      if (_isRecording)
                        Text(
                          'Recording... 00:0$_secondsRemaining',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: AppColors.riskHigh,
                          ),
                        )
                      else if (_isFinished)
                        const Text(
                          '✓ Voice Sample Captured',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppColors.riskLow,
                          ),
                        )
                      else
                        const Text(
                          'Tap microphone to start',
                          style: TailwindTheme.caption,
                        ),

                      const SizedBox(height: 24),

                      // Mic Record Button
                      GestureDetector(
                        onTap: _isRecording ? _stopRecording : _startRecording,
                        child: Container(
                          width: 86,
                          height: 86,
                          decoration: BoxDecoration(
                            color: _isRecording ? AppColors.riskHigh : AppColors.primaryAmber,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: (_isRecording ? AppColors.riskHigh : AppColors.primaryAmber)
                                    .withValues(alpha: 0.35),
                                blurRadius: 20,
                                spreadRadius: 6,
                              ),
                            ],
                          ),
                          child: Icon(
                            _isRecording ? Icons.stop : Icons.mic,
                            color: Colors.white,
                            size: 40,
                          ),
                        ),
                      ),

                      const Spacer(),
                      const SizedBox(height: 20),

                      // Results Preview & Proceed Button
                      if (_isFinished) ...[
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          decoration: TailwindTheme.cardDecoration(bg: Colors.white),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Column(
                                children: [
                                  const Text('Tremor Index', style: TailwindTheme.caption),
                                  Text(
                                    _tremorIndex.toStringAsFixed(2),
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.textMain,
                                    ),
                                  ),
                                ],
                              ),
                              Column(
                                children: [
                                  const Text('Pitch Stability', style: TailwindTheme.caption),
                                  Text(
                                    '${_pitchStability.toStringAsFixed(1)}%',
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.textMain,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            style: TailwindTheme.primaryButtonStyle,
                            onPressed: () {
                              Navigator.pushNamed(context, '/ai_analysis');
                            },
                            child: const Text('PROCEED TO AI ANALYSIS'),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}