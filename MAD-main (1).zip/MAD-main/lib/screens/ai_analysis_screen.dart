import 'package:flutter/material.dart';
import '../services/database_helper.dart';
import '../services/gemini_service.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';
import '../widgets/analysis_charts.dart';

class ChatMessage {
  final String id;
  final String sender; // 'user' or 'assistant'
  final String text;
  final DateTime timestamp;
  final Widget? customWidget;

  ChatMessage({
    required this.id,
    required this.sender,
    required this.text,
    required this.timestamp,
    this.customWidget,
  });
}

class AiAnalysisScreen extends StatefulWidget {
  const AiAnalysisScreen({super.key});

  @override
  State<AiAnalysisScreen> createState() => _AiAnalysisScreenState();
}

class _AiAnalysisScreenState extends State<AiAnalysisScreen> {
  final GeminiService _geminiService = GeminiService();
  final DatabaseHelper _dbHelper = DatabaseHelper();
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  bool _isAnalyzing = true;
  int _analysisStep = 0;
  bool _isAiTyping = false;
  Map<String, dynamic>? _analysisResults;

  // Screening inputs used for the AI analysis and the indicator chart.
  static const int _memoryScore = 82;
  static const double _voiceTremorIndex = 0.24;
  static const double _pitchStability = 94.5;

  final List<ChatMessage> _messages = [];

  final List<String> _quickPrompts = [
    'What does my 82/100 score mean?',
    'How can I lower my voice tremor index?',
    'Should I schedule a doctor visit?',
    'What exercises improve memory precision?',
    'What foods protect neurological health?',
  ];

  @override
  void initState() {
    super.initState();
    _runAnalysisPipeline();
  }

  @override
  void dispose() {
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _runAnalysisPipeline() async {
    await Future.delayed(const Duration(milliseconds: 600));
    if (mounted) setState(() => _analysisStep = 1);

    await Future.delayed(const Duration(milliseconds: 800));
    if (mounted) setState(() => _analysisStep = 2);

    final results = await _geminiService.analyzeNeurologicalData(
      memoryScore: _memoryScore,
      voiceTremorIndex: _voiceTremorIndex,
      voicePitchStability: _pitchStability,
      symptoms: ['Slight fatigue', 'Memory hesitation'],
    );

    // Save test record to SQLite DB
    await _dbHelper.saveTestRecord(
      userEmail: 'priya@neuronova.com',
      testType: 'Comprehensive Voice & Memory AI Screening',
      score: results['composite_score'] as int,
      riskLevel: results['risk_level'] as String,
      aiSummary: results['summary'] as String,
    );

    if (mounted) {
      setState(() {
        _analysisResults = results;
        _isAnalyzing = false;
      });

      // Populate Initial Chat Messages from AI
      _initChatMessages(results);
    }
  }

  void _initChatMessages(Map<String, dynamic> results) async {
    final int score = results['composite_score'] as int;
    final String riskLevel = results['risk_level'] as String;
    final String summary = results['summary'] as String;
    final List<String> recommendations = List<String>.from(results['recommendations'] ?? []);

    // Message 1: Initial AI Welcome Greeting
    _addMessage(ChatMessage(
      id: '1',
      sender: 'assistant',
      text: 'Hello Priya! I am your Gemini Neural Health Assistant. I have completed evaluating your acoustic vocal resonance and memory sequence screening.',
      timestamp: DateTime.now(),
    ));

    await Future.delayed(const Duration(milliseconds: 400));

    // Message 2: Score Card Widget inside Chat Stream
    if (mounted) {
      _addMessage(ChatMessage(
        id: '2',
        sender: 'assistant',
        text: 'Here is your overall neurological health synthesis card:',
        timestamp: DateTime.now(),
        customWidget: _buildScoreCard(score, riskLevel),
      ));
    }

    await Future.delayed(const Duration(milliseconds: 500));

    // Message 2b: Visual breakdown of the screening indicators
    if (mounted) {
      _addMessage(ChatMessage(
        id: '2b',
        sender: 'assistant',
        text: 'Here is a visual breakdown of the indicators behind your result:',
        timestamp: DateTime.now(),
        customWidget: _buildIndicatorChart(),
      ));
    }

    await Future.delayed(const Duration(milliseconds: 600));

    // Message 3: Executive Summary & Action Plan
    if (mounted) {
      _addMessage(ChatMessage(
        id: '3',
        sender: 'assistant',
        text: '$summary\n\nRecommended Action Steps:\n${recommendations.map((r) => '• $r').join('\n')}',
        timestamp: DateTime.now(),
      ));
    }

    _scrollToBottom();
  }

  void _addMessage(ChatMessage message) {
    setState(() {
      _messages.add(message);
    });
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _handleUserSendMessage(String text) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty || _isAiTyping) return;

    _textController.clear();

    // Add User Message to Chat
    _addMessage(ChatMessage(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      sender: 'user',
      text: trimmed,
      timestamp: DateTime.now(),
    ));

    // Show AI Typing Indicator
    setState(() => _isAiTyping = true);
    _scrollToBottom();

    // Query Gemini Chat API
    final String aiResponse = await _geminiService.chatWithAssistant(
      userMessage: trimmed,
      contextData: _analysisResults ?? {},
      chatHistory: _messages
          .map((m) => {'sender': m.sender, 'text': m.text})
          .toList(),
    );

    if (mounted) {
      setState(() => _isAiTyping = false);

      _addMessage(ChatMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        sender: 'assistant',
        text: aiResponse,
        timestamp: DateTime.now(),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 18,
                  backgroundColor: AppColors.primaryAmber.withValues(alpha: 0.2),
                  child: const Icon(Icons.psychology, color: AppColors.primaryAmber, size: 22),
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: AppColors.riskLow,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 1.5),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Gemini Health Assistant', style: TailwindTheme.h3),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        color: AppColors.riskLow,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Text(
                      'AI Clinical Neural Engine • Online',
                      style: TextStyle(fontSize: 10, color: AppColors.textSecondary),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.assessment_outlined, color: AppColors.primaryAmber),
            tooltip: 'View Doctor Report',
            onPressed: () => Navigator.pushNamed(context, '/doctor'),
          ),
        ],
      ),
      body: SafeArea(
        child: _isAnalyzing
            ? _buildAnalyzingState()
            : Column(
                children: [
                  // Chat Messages Area
                  Expanded(
                    child: ListView.builder(
                      controller: _scrollController,
                      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                      itemCount: _messages.length + (_isAiTyping ? 1 : 0),
                      itemBuilder: (context, index) {
                        if (index == _messages.length && _isAiTyping) {
                          return _buildTypingIndicator();
                        }
                        return _buildMessageBubble(_messages[index]);
                      },
                    ),
                  ),

                  // Quick Prompt Chips Bar
                  if (!_isAiTyping) _buildQuickPromptsBar(),

                  // Bottom Input Field & Controls
                  _buildInputBar(),
                ],
              ),
      ),
    );
  }

  Widget _buildAnalyzingState() {
    return Column(
      children: [
        const Spacer(),
        Container(
          width: 110,
          height: 110,
          decoration: BoxDecoration(
            color: AppColors.cardBg,
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.primaryAmber, width: 2),
            boxShadow: [
              BoxShadow(
                color: AppColors.primaryAmber.withValues(alpha: 0.25),
                blurRadius: 24,
                spreadRadius: 8,
              ),
            ],
          ),
          child: const Center(
            child: CircularProgressIndicator(
              color: AppColors.primaryAmber,
              strokeWidth: 4,
            ),
          ),
        ),
        const SizedBox(height: 32),
        const Text('Analyzing Patient Metrics', style: TailwindTheme.h2),
        const SizedBox(height: 8),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 32.0),
          child: Text(
            'Gemini Neural Assistant is synthesizing vocal resonance & memory recall indicators into your personal chat dashboard.',
            textAlign: TextAlign.center,
            style: TailwindTheme.body,
          ),
        ),
        const Spacer(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32.0),
          child: Column(
            children: [
              _checkStep('Processing Acoustic Voice Signals', _analysisStep >= 0),
              _checkStep('Evaluating Memory Sequence Recall', _analysisStep >= 1),
              _checkStep('Initializing Gemini AI Assistant Chat', _analysisStep >= 2),
            ],
          ),
        ),
        const Spacer(),
      ],
    );
  }

  Widget _checkStep(String title, bool done) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        children: [
          Icon(
            done ? Icons.check_circle : Icons.radio_button_unchecked,
            color: done ? AppColors.riskLow : AppColors.textMuted,
            size: 20,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                color: done ? AppColors.textMain : AppColors.textSecondary,
                fontWeight: done ? FontWeight.w600 : FontWeight.normal,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIndicatorChart() {
    final double vocalSteadiness =
        ((1 - _voiceTremorIndex) * 100).clamp(0, 100).toDouble();
    final double pitch = _pitchStability.clamp(0, 100).toDouble();

    return ChartCard(
      margin: const EdgeInsets.only(top: 8, bottom: 4),
      title: 'Screening Indicators',
      subtitle: 'Higher is better - dashed line marks the low-risk range (75+)',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ScoreBarChart(
            height: 200,
            labels: const ['Memory', 'Voice', 'Pitch'],
            values: [_memoryScore.toDouble(), vocalSteadiness, pitch],
          ),
          const SizedBox(height: 8),
          const ChartLegend(items: ChartLegend.riskBands),
        ],
      ),
    );
  }

  Widget _buildScoreCard(int score, String riskLevel) {
    final Color riskColor = score < 40
        ? AppColors.riskHigh
        : score < 70
            ? AppColors.riskModerate
            : AppColors.riskLow;

    return Container(
      margin: const EdgeInsets.only(top: 8, bottom: 4),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.cardBorder),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryAmber.withValues(alpha: 0.08),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('OVERALL HEALTH METRIC', style: TailwindTheme.caption),
                  Text('Neurological Synthesis', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: riskColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: riskColor),
                ),
                child: Text(
                  riskLevel,
                  style: TextStyle(
                    color: riskColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
          const Divider(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                children: [
                  Text(
                    '$score / 100',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: riskColor,
                    ),
                  ),
                  const Text('Composite Score', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ],
              ),
              Container(width: 1, height: 36, color: AppColors.cardBorder),
              const Column(
                children: [
                  Text('82%', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.textMain)),
                  Text('Memory Recall', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ],
              ),
              Container(width: 1, height: 36, color: AppColors.cardBorder),
              const Column(
                children: [
                  Text('0.24', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.textMain)),
                  Text('Voice Tremor', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage msg) {
    final bool isUser = msg.sender == 'user';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isUser) ...[
            CircleAvatar(
              radius: 16,
              backgroundColor: AppColors.primaryAmber.withValues(alpha: 0.2),
              child: const Icon(Icons.psychology, color: AppColors.primaryAmber, size: 18),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: isUser ? AppColors.primaryAmber : AppColors.surface,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(16),
                      topRight: const Radius.circular(16),
                      bottomLeft: Radius.circular(isUser ? 16 : 4),
                      bottomRight: Radius.circular(isUser ? 4 : 16),
                    ),
                    border: isUser ? null : Border.all(color: AppColors.cardBorder),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.03),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        msg.text,
                        style: TextStyle(
                          fontSize: 14,
                          color: isUser ? Colors.white : AppColors.textMain,
                          height: 1.4,
                        ),
                      ),
                      if (msg.customWidget != null) msg.customWidget!,
                    ],
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '${msg.timestamp.hour.toString().padLeft(2, '0')}:${msg.timestamp.minute.toString().padLeft(2, '0')}',
                  style: const TextStyle(fontSize: 10, color: AppColors.textSecondary),
                ),
              ],
            ),
          ),
          if (isUser) ...[
            const SizedBox(width: 8),
            const CircleAvatar(
              radius: 16,
              backgroundColor: AppColors.primaryAmber,
              child: Icon(Icons.person, color: Colors.white, size: 18),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        children: [
          CircleAvatar(
            radius: 16,
            backgroundColor: AppColors.primaryAmber.withValues(alpha: 0.2),
            child: const Icon(Icons.psychology, color: AppColors.primaryAmber, size: 18),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.cardBorder),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Gemini AI is analyzing',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontStyle: FontStyle.italic),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppColors.primaryAmber,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickPromptsBar() {
    return Container(
      height: 42,
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _quickPrompts.length,
        separatorBuilder: (_, index) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final prompt = _quickPrompts[index];
          return ActionChip(
            backgroundColor: AppColors.surface,
            side: const BorderSide(color: AppColors.cardBorder),
            label: Text(
              prompt,
              style: const TextStyle(fontSize: 12, color: AppColors.textMain),
            ),
            avatar: const Icon(Icons.auto_awesome, size: 14, color: AppColors.primaryAmber),
            onPressed: () => _handleUserSendMessage(prompt),
          );
        },
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: AppColors.cardBorder)),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _textController,
              textInputAction: TextInputAction.send,
              onSubmitted: _handleUserSendMessage,
              decoration: InputDecoration(
                hintText: 'Ask Gemini about your health data...',
                hintStyle: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                filled: true,
                fillColor: AppColors.background,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: const BorderSide(color: AppColors.cardBorder),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: const BorderSide(color: AppColors.cardBorder),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: const BorderSide(color: AppColors.primaryAmber, width: 1.5),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Material(
            color: AppColors.primaryAmber,
            shape: const CircleBorder(),
            child: IconButton(
              icon: const Icon(Icons.send, color: Colors.white, size: 18),
              onPressed: () => _handleUserSendMessage(_textController.text),
            ),
          ),
        ],
      ),
    );
  }
}