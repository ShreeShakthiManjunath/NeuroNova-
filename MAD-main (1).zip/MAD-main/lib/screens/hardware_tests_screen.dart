import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class HardwareTestsScreen extends StatelessWidget {
  const HardwareTestsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Hardware Test Suite', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Hardware Assessment', style: TailwindTheme.h2),
              const SizedBox(height: 6),
              const Text(
                'These motor tests require connection to the Smart Neuro Cube.',
                style: TailwindTheme.body,
              ),
              const SizedBox(height: 24),

              _testCard(
                icon: Icons.vibration,
                title: 'Hand Tremor Test',
                subtitle: 'Measures involuntary resting & posture hand tremor frequency.',
              ),
              const SizedBox(height: 12),
              _testCard(
                icon: Icons.touch_app,
                title: 'Finger Tapping Test',
                subtitle: 'Evaluates motor cadence, speed, and rhythm consistency.',
              ),
              const SizedBox(height: 12),
              _testCard(
                icon: Icons.accessibility_new,
                title: 'Balance Test',
                subtitle: 'Assesses postural stability & center-of-mass sway.',
              ),

              const Spacer(),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: TailwindTheme.primaryButtonStyle,
                  onPressed: () => Navigator.pushNamed(context, '/hardware_progress'),
                  child: const Text('START HARDWARE TESTS'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _testCard({required IconData icon, required String title, required String subtitle}) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.cardBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: AppColors.primaryAmber, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: AppColors.textMain,
                  ),
                ),
                const SizedBox(height: 4),
                Text(subtitle, style: TailwindTheme.caption),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
