import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';
import '../widgets/anatomical_3d_body_widget.dart';

class Analysis3dScreen extends StatefulWidget {
  const Analysis3dScreen({super.key});

  @override
  State<Analysis3dScreen> createState() => _Analysis3dScreenState();
}

class _Analysis3dScreenState extends State<Analysis3dScreen> {
  int _activeTab = 0; // 0: Tremor Map, 1: Balance Map
  bool _isAnterior = true; // Front vs Back view
  double _rotationY = 0.0; // Radians, interactive 3D rotation
  bool _showHeatmap = true;
  bool _showSkeleton = true;
  bool _showSensors = true;

  AnatomicalRegion? _selectedRegion;

  void _onTabChanged(int index) {
    setState(() {
      _activeTab = index;
      _selectedRegion = null; // reset selection when switching tabs
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('3D Anatomical Analysis', style: TailwindTheme.h3),
        actions: [
          IconButton(
            icon: Icon(
              _isAnterior ? Icons.flip_camera_android : Icons.sync,
              color: AppColors.primaryAmber,
            ),
            tooltip: _isAnterior ? 'Switch to Posterior (Back) View' : 'Switch to Anterior (Front) View',
            onPressed: () {
              setState(() {
                _isAnterior = !_isAnterior;
                _rotationY = _isAnterior ? 0.0 : math.pi;
              });
            },
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 1. Map Mode Tab Switcher
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: AppColors.cardBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.cardBorder),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => _onTabChanged(0),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: _activeTab == 0 ? AppColors.primaryAmber : Colors.transparent,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.vibration,
                                  size: 18,
                                  color: _activeTab == 0 ? Colors.white : AppColors.textMain,
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'Tremor Map',
                                  style: TextStyle(
                                    color: _activeTab == 0 ? Colors.white : AppColors.textMain,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => _onTabChanged(1),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: _activeTab == 1 ? AppColors.primaryAmber : Colors.transparent,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.accessibility_new,
                                  size: 18,
                                  color: _activeTab == 1 ? Colors.white : AppColors.textMain,
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'Balance Map',
                                  style: TextStyle(
                                    color: _activeTab == 1 ? Colors.white : AppColors.textMain,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),

              // 2. Layer Toggle Filter Chips
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    FilterChip(
                      selected: _showHeatmap,
                      label: const Text('Heatmap'),
                      avatar: const Icon(Icons.local_fire_department, size: 16),
                      selectedColor: AppColors.cardBg,
                      checkmarkColor: AppColors.primaryAmber,
                      side: const BorderSide(color: AppColors.cardBorder),
                      onSelected: (val) => setState(() => _showHeatmap = val),
                    ),
                    const SizedBox(width: 8),
                    FilterChip(
                      selected: _showSkeleton,
                      label: const Text('Skeleton & Joints'),
                      avatar: const Icon(Icons.polyline, size: 16),
                      selectedColor: AppColors.cardBg,
                      checkmarkColor: AppColors.primaryAmber,
                      side: const BorderSide(color: AppColors.cardBorder),
                      onSelected: (val) => setState(() => _showSkeleton = val),
                    ),
                    const SizedBox(width: 8),
                    FilterChip(
                      selected: _showSensors,
                      label: const Text('IMU Sensors'),
                      avatar: const Icon(Icons.sensors, size: 16),
                      selectedColor: AppColors.cardBg,
                      checkmarkColor: AppColors.primaryAmber,
                      side: const BorderSide(color: AppColors.cardBorder),
                      onSelected: (val) => setState(() => _showSensors = val),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),

              // 3. Interactive 3D Vector Body Container
              Container(
                width: double.infinity,
                height: (MediaQuery.of(context).size.height * 0.42).clamp(250.0, 420.0),
                decoration: TailwindTheme.cardDecoration(bg: Colors.white),
                child: Stack(
                  children: [
                    // GestureDetector for 3D Drag Rotation
                    GestureDetector(
                      onPanUpdate: (details) {
                        setState(() {
                          _rotationY += details.delta.dx * 0.01;
                        });
                      },
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Anatomical3dBodyWidget(
                          activeTab: _activeTab,
                          isAnterior: _isAnterior,
                          rotationY: _rotationY,
                          showHeatmap: _showHeatmap,
                          showSkeleton: _showSkeleton,
                          showSensors: _showSensors,
                          selectedRegion: _selectedRegion,
                          onRegionSelected: (region) {
                            setState(() {
                              _selectedRegion = region;
                            });
                          },
                        ),
                      ),
                    ),

                    // Top Left Status Badge
                    Positioned(
                      top: 12,
                      left: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppColors.surface.withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppColors.cardBorder),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: AppColors.riskLow,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              _isAnterior ? 'ANTERIOR VIEW' : 'POSTERIOR VIEW',
                              style: const TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: AppColors.textMain,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Top Right Drag Angle Control Hint
                    Positioned(
                      top: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.surface.withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppColors.cardBorder),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.threed_rotation, size: 14, color: AppColors.primaryAmber),
                            const SizedBox(width: 4),
                            Text(
                              'Drag to rotate 360°',
                              style: TextStyle(
                                fontSize: 10,
                                color: AppColors.textSecondary.withValues(alpha: 0.9),
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Bottom Instruction Banner
                    Positioned(
                      bottom: 10,
                      left: 16,
                      right: 16,
                      child: Center(
                        child: Text(
                          _selectedRegion == null
                              ? 'Tap any joint node or glowing zone for detailed diagnostics'
                              : 'Selected: ${_selectedRegion!.name}',
                          style: TextStyle(
                            fontSize: 11,
                            fontStyle: FontStyle.italic,
                            color: AppColors.textSecondary.withValues(alpha: 0.8),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 4. Region Diagnostics & Metrics Card
              _buildRegionMetricsCard(),

              const SizedBox(height: 20),

              // 5. Daily Progress Trend Action Button
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  style: TailwindTheme.primaryButtonStyle,
                  icon: const Icon(Icons.show_chart, color: Colors.white),
                  onPressed: () => Navigator.pushNamed(context, '/daily_progress'),
                  label: const Text('VIEW DAILY PROGRESS TREND'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRegionMetricsCard() {
    final region = _selectedRegion;

    if (region == null) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: TailwindTheme.cardDecoration(),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.primaryAmber.withValues(alpha: 0.15),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.touch_app, color: AppColors.primaryAmber, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _activeTab == 0 ? 'Tremor Overview: Upper Body Focus' : 'Balance Overview: Lower Body Focus',
                    style: TailwindTheme.h3.copyWith(fontSize: 15),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _activeTab == 0
                        ? 'Peak activity detected in Right Wrist (6.8 Hz).'
                        : 'Postural displacement observed at Lumbar Core (12.4°).',
                    style: TailwindTheme.body.copyWith(fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(region.name, style: TailwindTheme.h3),
                  Text(region.location, style: TailwindTheme.caption),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: region.statusColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: region.statusColor),
                ),
                child: Text(
                  region.statusText,
                  style: TextStyle(
                    color: region.statusColor,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const Divider(height: 24),
          Row(
            children: [
              Expanded(
                child: _buildMetricTile(
                  label: 'Tremor Frequency',
                  value: '${region.tremorFreq} Hz',
                  icon: Icons.graphic_eq,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildMetricTile(
                  label: 'Sway Angle',
                  value: '${region.swayAngle}°',
                  icon: Icons.screen_rotation,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.cardBorder.withValues(alpha: 0.6)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.info_outline, size: 16, color: AppColors.primaryAmber),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    region.clinicalNote,
                    style: const TextStyle(fontSize: 12, color: AppColors.textMain, height: 1.3),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricTile({
    required String label,
    required String value,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.cardBg.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.primaryAmber),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
              Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textMain)),
            ],
          ),
        ],
      ),
    );
  }
}
