import 'package:flutter/material.dart';
import '../services/database_helper.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final DatabaseHelper _dbHelper = DatabaseHelper();
  List<Map<String, dynamic>> _records = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final list = await _dbHelper.getTestRecords('priya@neuronova.com');
    if (mounted) {
      setState(() {
        _records = list;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Test History & Analytics', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Screening Analytics & History', style: TailwindTheme.h2),
              const SizedBox(height: 6),
              const Text(
                'Historical test records stored locally in SQLite.',
                style: TailwindTheme.body,
              ),
              const SizedBox(height: 20),

              // Analytics Summary Card (Design 17 from image spec)
              Container(
                padding: const EdgeInsets.all(18),
                decoration: TailwindTheme.cardDecoration(bg: Colors.white),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Risk Analytics Distribution', style: TailwindTheme.h3),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        _analyticsBadge('High Risk', '20%', AppColors.riskHigh),
                        const SizedBox(width: 8),
                        _analyticsBadge('Moderate', '50%', AppColors.riskModerate),
                        const SizedBox(width: 8),
                        _analyticsBadge('Low Risk', '30%', AppColors.riskLow),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              const Text('Recent Records', style: TailwindTheme.h3),
              const SizedBox(height: 10),

              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator(color: AppColors.primaryAmber))
                    : _records.isEmpty
                        ? ListView(
                            children: [
                              _historyCard('21 Jul 2026', 'Comprehensive AI Screening', '82 / 100', 'Moderate Risk', AppColors.riskModerate),
                              _historyCard('18 Jul 2026', 'Voice Acoustic Assessment', '88 / 100', 'Low Risk', AppColors.riskLow),
                              _historyCard('14 Jul 2026', 'Sequence Memory Assessment', '65 / 100', 'Moderate Risk', AppColors.riskModerate),
                            ],
                          )
                        : ListView.builder(
                            itemCount: _records.length,
                            itemBuilder: (context, index) {
                              final item = _records[index];
                              final String dateStr = item['created_at'] != null
                                  ? item['created_at'].toString().split('T').first
                                  : '2026-07-21';
                              final String testType = item['test_type'] ?? 'AI Screening';
                              final String scoreStr = '${item['score']} / 100';
                              final String risk = item['risk_level'] ?? 'Moderate Risk';
                              final Color riskColor = risk.contains('High')
                                  ? AppColors.riskHigh
                                  : risk.contains('Low')
                                      ? AppColors.riskLow
                                      : AppColors.riskModerate;

                              return _historyCard(dateStr, testType, scoreStr, risk, riskColor);
                            },
                          ),
              ),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: TailwindTheme.primaryButtonStyle,
                  onPressed: () => Navigator.pushNamed(context, '/profile'),
                  child: const Text('GO TO PROFILE SETTINGS'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _analyticsBadge(String label, String pct, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Column(
          children: [
            Text(pct, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _historyCard(String date, String title, String score, String risk, Color tagColor) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: AppColors.textMain,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Date: $date  •  Score: $score',
                  style: TailwindTheme.caption,
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: tagColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: tagColor.withValues(alpha: 0.3)),
            ),
            child: Text(
              risk,
              style: TextStyle(
                color: tagColor,
                fontWeight: FontWeight.bold,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}