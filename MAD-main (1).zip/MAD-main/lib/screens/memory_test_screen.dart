import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

enum MemoryGameState { idle, displaying, inputting, completed }

class MemoryTestScreen extends StatefulWidget {
  const MemoryTestScreen({super.key});

  @override
  State<MemoryTestScreen> createState() => _MemoryTestScreenState();
}

class _MemoryTestScreenState extends State<MemoryTestScreen> {
  final Random _random = Random();
  List<int> _targetSequence = [];
  List<int> _userInput = [];
  MemoryGameState _gameState = MemoryGameState.idle;
  int _score = 0;
  String _feedbackMessage = '';
  Timer? _flashTimer;

  @override
  void initState() {
    super.initState();
    _startNewGame();
  }

  void _startNewGame() {
    _flashTimer?.cancel();

    // Generate a fresh, random set of 4 digits
    List<int> newSequence;
    do {
      newSequence = List.generate(4, (_) => _random.nextInt(9) + 1);
    } while (newSequence.toString() == _targetSequence.toString());

    setState(() {
      _targetSequence = newSequence;
      _userInput = [];
      _gameState = MemoryGameState.displaying;
      _feedbackMessage = 'Memorize the new sequence...';
    });

    // Flash sequence for 2.5 seconds, then hide and show input keypad
    _flashTimer = Timer(const Duration(milliseconds: 2500), () {
      if (mounted) {
        setState(() {
          _gameState = MemoryGameState.inputting;
          _feedbackMessage = 'Repeat the sequence in order:';
        });
      }
    });
  }

  void _handleKeyPress(int digit) {
    if (_gameState != MemoryGameState.inputting) return;
    if (_userInput.length < _targetSequence.length) {
      setState(() {
        _userInput.add(digit);
      });
    }
  }

  void _handleBackspace() {
    if (_userInput.isNotEmpty && _gameState == MemoryGameState.inputting) {
      setState(() {
        _userInput.removeLast();
      });
    }
  }

  void _evaluateResult() {
    int matches = 0;
    for (int i = 0; i < _targetSequence.length; i++) {
      if (i < _userInput.length && _userInput[i] == _targetSequence[i]) {
        matches++;
      }
    }

    _score = ((matches / _targetSequence.length) * 100).round();

    setState(() {
      _gameState = MemoryGameState.completed;
      if (_score >= 75) {
        _feedbackMessage = 'Great Job! High Recall Precision.';
      } else {
        _feedbackMessage = 'Test Complete. Tap Retry for a new set of numbers.';
      }
    });
  }

  @override
  void dispose() {
    _flashTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Cognitive Memory Test', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              const Text('Sequence Recall', style: TailwindTheme.h2),
              const SizedBox(height: 6),
              Text(_feedbackMessage, style: TailwindTheme.body),
              const SizedBox(height: 32),

              // Sequence Cards Display Area
              Container(
                padding: const EdgeInsets.all(24),
                decoration: TailwindTheme.cardDecoration(),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: List.generate(_targetSequence.length, (index) {
                    final bool isDisplaying = _gameState == MemoryGameState.displaying;
                    final bool hasInput = index < _userInput.length;
                    final String displayVal = isDisplaying
                        ? '${_targetSequence[index]}'
                        : hasInput
                            ? '${_userInput[index]}'
                            : '?';

                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 56,
                      height: 64,
                      decoration: BoxDecoration(
                        color: isDisplaying
                            ? AppColors.primaryAmber
                            : hasInput
                                ? Colors.white
                                : AppColors.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: AppColors.primaryAmber,
                          width: 1.5,
                        ),
                      ),
                      child: Center(
                        child: Text(
                          displayVal,
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            color: isDisplaying
                                ? Colors.white
                                : hasInput
                                    ? AppColors.textMain
                                    : AppColors.textMuted,
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ),

              const Spacer(),

              // Game Results State
              if (_gameState == MemoryGameState.completed) ...[
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: TailwindTheme.cardDecoration(bg: Colors.white),
                  child: Column(
                    children: [
                      const Text('TEST RESULT SCORE', style: TailwindTheme.caption),
                      const SizedBox(height: 6),
                      Text(
                        '$_score / 100',
                        style: TextStyle(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: _score >= 75 ? AppColors.riskLow : AppColors.riskModerate,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        style: TailwindTheme.secondaryButtonStyle,
                        icon: const Icon(Icons.refresh),
                        label: const Text('RETRY'),
                        onPressed: _startNewGame,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        style: TailwindTheme.primaryButtonStyle,
                        onPressed: () {
                          Navigator.pushNamed(context, '/ai_analysis');
                        },
                        child: const Text('PROCEED'),
                      ),
                    ),
                  ],
                ),
              ] else if (_gameState == MemoryGameState.inputting) ...[
                // Numeric Keypad
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 1.6,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemCount: 12,
                  itemBuilder: (context, index) {
                    if (index == 9) {
                      return IconButton(
                        icon: const Icon(Icons.backspace_outlined, color: AppColors.riskHigh),
                        onPressed: _handleBackspace,
                      );
                    } else if (index == 10) {
                      return _keypadButton(0, () => _handleKeyPress(0));
                    } else if (index == 11) {
                      return IconButton(
                        icon: const Icon(Icons.check_circle, color: AppColors.riskLow, size: 36),
                        onPressed: _userInput.isNotEmpty ? _evaluateResult : null,
                      );
                    }
                    final number = index + 1;
                    return _keypadButton(number, () => _handleKeyPress(number));
                  },
                ),
              ],
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _keypadButton(int number, VoidCallback onTap) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: AppColors.textMain,
        elevation: 1,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Color(0xFFFDE68A)),
        ),
      ),
      onPressed: onTap,
      child: Text(
        '$number',
        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
      ),
    );
  }
}