import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final AuthService _authService = AuthService();
  String _userName = 'Patient';

  @override
  void initState() {
    super.initState();
    _loadUser();
  }

  Future<void> _loadUser() async {
    final user = await _authService.getCurrentUser();
    if (mounted && user['name'] != null && user['name']!.isNotEmpty) {
      setState(() => _userName = user['name']!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.pushNamed(context, '/assistant'),
        backgroundColor: AppColors.primaryAmber,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.psychology),
        label: const Text('Ask NeuroNova'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 90),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // User Greeting Banner
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Hello, $_userName 👋', style: TailwindTheme.h2),
                        const SizedBox(height: 4),
                        const Text('Welcome to NeuroNova AI Screening', style: TailwindTheme.body),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pushNamed(context, '/emergency_sos'),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.riskHigh.withValues(alpha: 0.1),
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.riskHigh),
                      ),
                      child: const Icon(Icons.warning_amber_rounded, color: AppColors.riskHigh, size: 24),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () => Navigator.pushNamed(context, '/profile'),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.cardBg,
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.cardBorder),
                      ),
                      child: const Icon(Icons.person, color: AppColors.primaryAmber),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Overall Health Status Card
              GestureDetector(
                onTap: () => Navigator.pushNamed(context, '/risk_report'),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  decoration: TailwindTheme.cardDecoration(bg: Colors.white),
                  child: Column(
                    children: [
                      const Text('OVERALL HEALTH STATUS', style: TailwindTheme.caption),
                      const SizedBox(height: 6),
                      const Text(
                        'Moderate Risk',
                        style: TextStyle(
                          color: AppColors.riskModerate,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 20),
                      Stack(
                        alignment: Alignment.center,
                        children: [
                          SizedBox(
                            width: 120,
                            height: 120,
                            child: CircularProgressIndicator(
                              value: 0.62,
                              strokeWidth: 10,
                              valueColor: const AlwaysStoppedAnimation<Color>(AppColors.riskModerate),
                              backgroundColor: AppColors.cardBg,
                            ),
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Text('62', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: AppColors.textMain)),
                              Text('/100', style: TailwindTheme.caption),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 28),

              // Complete Feature Suite Grid
              const Text('Full Screening & Diagnostic Suite', style: TailwindTheme.h3),
              const SizedBox(height: 16),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 3,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: [
                  _tile(context, Icons.mic, 'Voice Test', '/voice_test'),
                  _tile(context, Icons.psychology, 'Memory Test', '/memory_test'),
                  _tile(context, Icons.bluetooth, 'Connect Cube', '/connect_cube'),
                  _tile(context, Icons.developer_board, 'Hardware Suite', '/hardware_tests'),
                  _tile(context, Icons.analytics, 'AI Analysis', '/ai_analysis'),
                  _tile(context, Icons.assignment, 'Symptom Screen', '/symptom'),
                  _tile(context, Icons.insert_chart, 'Risk Report', '/risk_report'),
                  _tile(context, Icons.accessibility, '3D Body Map', '/analysis_3d'),
                  _tile(context, Icons.show_chart, 'Daily Progress', '/daily_progress'),
                  _tile(context, Icons.history, 'History', '/history'),
                  _tile(context, Icons.local_hospital, 'Doctor & Hospital', '/doctor'),
                  _tile(context, Icons.warning_amber_rounded, 'Emergency SOS', '/emergency_sos'),
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: AppColors.primaryAmber,
        unselectedItemColor: AppColors.textSecondary,
        currentIndex: 0,
        type: BottomNavigationBarType.fixed,
        onTap: (index) {
          if (index == 1) Navigator.pushNamed(context, '/history');
          if (index == 2) Navigator.pushNamed(context, '/ai_analysis');
          if (index == 3) Navigator.pushNamed(context, '/profile');
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'History'),
          BottomNavigationBarItem(icon: Icon(Icons.analytics), label: 'Analysis'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String label, String route) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Container(
        decoration: TailwindTheme.cardDecoration(),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppColors.primaryAmber, size: 28),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                color: AppColors.textMain,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}