import 'package:flutter/material.dart';

import '../services/ai_service.dart';
import '../services/neuronova_assistant_service.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class _AssistantMessage {
  final bool fromUser;
  final String text;
  final String? route;
  final String? routeLabel;

  const _AssistantMessage({
    required this.fromUser,
    required this.text,
    this.route,
    this.routeLabel,
  });
}

/// Floating, app-wide helper: "NeuroNova Assistant".
class NeuroNovaAssistantScreen extends StatefulWidget {
  const NeuroNovaAssistantScreen({super.key});

  @override
  State<NeuroNovaAssistantScreen> createState() =>
      _NeuroNovaAssistantScreenState();
}

class _NeuroNovaAssistantScreenState extends State<NeuroNovaAssistantScreen> {
  final NeuroNovaAssistantService _assistant = NeuroNovaAssistantService();
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scroll = ScrollController();

  final List<_AssistantMessage> _messages = [];
  bool _typing = false;

  // Latest screening snapshot (same source the Home screen summarises).
  late final Map<String, dynamic> _context = AiService().fetchMockAnalysisReport();

  static const List<String> _quickPrompts = [
    'What can you do?',
    'How do I take the voice test?',
    'What does my score mean?',
    'How does the 3D body map work?',
    'Should I see a doctor?',
    'How can I improve my brain health?',
  ];

  @override
  void initState() {
    super.initState();
    _messages.add(const _AssistantMessage(
      fromUser: false,
      text: 'Hi! I\'m the NeuroNova Assistant. Ask me about your tests, '
          'your results, the 3D body map or the Neuro Cube sensors - I can '
          'also take you straight to any screen.',
    ));
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  Future<void> _send(String text) async {
    final message = text.trim();
    if (message.isEmpty || _typing) return;

    // History sent to the model = everything before this new message.
    final history = [
      for (final m in _messages)
        {'sender': m.fromUser ? 'user' : 'assistant', 'text': m.text},
    ];

    _controller.clear();
    setState(() {
      _messages.add(_AssistantMessage(fromUser: true, text: message));
      _typing = true;
    });
    _scrollToBottom();

    final reply = await _assistant.ask(
      userMessage: message,
      history: history,
      context: _context,
    );

    if (!mounted) return;
    setState(() {
      _typing = false;
      _messages.add(_AssistantMessage(
        fromUser: false,
        text: reply.text,
        route: reply.route,
        routeLabel: reply.routeLabel,
      ));
    });
    _scrollToBottom();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textMain),
        titleSpacing: 0,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: const BoxDecoration(
                color: AppColors.cardBg,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.psychology,
                  color: AppColors.primaryAmber, size: 22),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(NeuroNovaAssistantService.assistantName,
                    style: TextStyle(
                        color: AppColors.textMain,
                        fontSize: 16,
                        fontWeight: FontWeight.bold)),
                Text('Your NeuroNova guide', style: TailwindTheme.caption),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scroll,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              itemCount: _messages.length + (_typing ? 1 : 0),
              itemBuilder: (context, i) {
                if (i == _messages.length) return _typingBubble();
                return _bubble(_messages[i]);
              },
            ),
          ),
          _quickChips(),
          _disclaimer(),
          _inputBar(),
        ],
      ),
    );
  }

  Widget _bubble(_AssistantMessage m) {
    final bool user = m.fromUser;
    return Align(
      alignment: user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: user ? AppColors.primaryAmber : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(user ? 16 : 4),
            bottomRight: Radius.circular(user ? 4 : 16),
          ),
          border: user ? null : Border.all(color: AppColors.cardBorder),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              m.text,
              style: TextStyle(
                color: user ? Colors.white : AppColors.textMain,
                fontSize: 14,
                height: 1.4,
              ),
            ),
            if (m.route != null) ...[
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () => Navigator.pushNamed(context, m.route!),
                icon: const Icon(Icons.arrow_forward, size: 16),
                label: Text(m.routeLabel ?? 'Open'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primaryDark,
                  side: const BorderSide(color: AppColors.primaryAmber),
                  visualDensity: VisualDensity.compact,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _typingBubble() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.cardBorder),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: const [
            SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(
                  strokeWidth: 2, color: AppColors.primaryAmber),
            ),
            SizedBox(width: 10),
            Text('NeuroNova Assistant is typing...',
                style: TailwindTheme.caption),
          ],
        ),
      ),
    );
  }

  Widget _quickChips() {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _quickPrompts.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) => ActionChip(
          label: Text(_quickPrompts[i],
              style: const TextStyle(fontSize: 12, color: AppColors.textMain)),
          backgroundColor: AppColors.cardBg,
          side: const BorderSide(color: AppColors.cardBorder),
          onPressed: () => _send(_quickPrompts[i]),
        ),
      ),
    );
  }

  Widget _disclaimer() {
    return const Padding(
      padding: EdgeInsets.fromLTRB(16, 4, 16, 6),
      child: Text(
        'Screening guidance only - not a medical diagnosis.',
        style: TailwindTheme.caption,
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _inputBar() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        color: Colors.white,
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                textInputAction: TextInputAction.send,
                onSubmitted: _send,
                minLines: 1,
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: 'Ask the NeuroNova Assistant...',
                  hintStyle:
                      const TextStyle(color: Color(0xFF94A3B8), fontSize: 14),
                  filled: true,
                  fillColor: AppColors.background,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: const BorderSide(color: AppColors.cardBorder),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: const BorderSide(
                        color: AppColors.primaryAmber, width: 2),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            CircleAvatar(
              backgroundColor: AppColors.primaryAmber,
              child: IconButton(
                icon: const Icon(Icons.send_rounded,
                    color: Colors.white, size: 20),
                onPressed: _typing ? null : () => _send(_controller.text),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
