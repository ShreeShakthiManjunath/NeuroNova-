import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class DoctorScreen extends StatelessWidget {
  const DoctorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Specialist Consultation', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const Text('Recommended Neurologist', style: TailwindTheme.h2),
            const SizedBox(height: 6),
            const Text(
              'Based on your AI diagnostic risk matrix evaluation.',
              style: TailwindTheme.body,
            ),
            const SizedBox(height: 20),

            // Doctor Profile Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: TailwindTheme.cardDecoration(bg: Colors.white),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: AppColors.cardBg,
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.cardBorder),
                        ),
                        child: const Icon(
                          Icons.local_hospital,
                          color: AppColors.primaryAmber,
                          size: 30,
                        ),
                      ),
                      const SizedBox(width: 16),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Dr. Arjun Sharma, MD',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: AppColors.textMain,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Senior Clinical Neurologist • 12+ Yrs Experience',
                              style: TailwindTheme.caption,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton.icon(
                      style: TailwindTheme.primaryButtonStyle,
                      icon: const Icon(Icons.calendar_today, size: 18),
                      label: const Text('BOOK CONSULTATION APPOINTMENT'),
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Consultation request sent to Dr. Arjun Sharma.'),
                            backgroundColor: AppColors.riskLow,
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Nearby Hospitals Section (From Image Specification)
            const Text('Nearby Hospitals & Medical Centers', style: TailwindTheme.h3),
            const SizedBox(height: 12),

            _hospitalCard('Care Neuro Center', 'Specialized Movement Disorder Clinic', '1.2 km'),
            const SizedBox(height: 10),
            _hospitalCard('City Brain & Spine Hospital', 'Tertiary Neurological Emergency Care', '2.4 km'),

            const SizedBox(height: 24),

            // View History & Return Buttons
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton(
                style: TailwindTheme.secondaryButtonStyle,
                onPressed: () => Navigator.pushNamed(context, '/history'),
                child: const Text('VIEW ALL TEST RECORDS HISTORY'),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.textSecondary,
                  side: const BorderSide(color: Color(0xFFFDE68A)),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
                child: const Text('RETURN TO DASHBOARD'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hospitalCard(String name, String detail, String distance) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.cardBg,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.local_hospital, color: AppColors.primaryAmber, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: AppColors.textMain)),
                const SizedBox(height: 2),
                Text(detail, style: TailwindTheme.caption),
              ],
            ),
          ),
          Text(
            distance,
            style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primaryAmber, fontSize: 13),
          ),
        ],
      ),
    );
  }
}