import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final AuthService _authService = AuthService();
  String _name = 'Dr. Priya Sharma';
  String _email = 'priya@neuronova.com';

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final user = await _authService.getCurrentUser();
    if (mounted) {
      setState(() {
        _name = user['name'] ?? 'Dr. Priya Sharma';
        _email = user['email'] ?? 'priya@neuronova.com';
      });
    }
  }

  Future<void> _handleLogout() async {
    await _authService.logoutUser();
    if (mounted) {
      Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('User Account Profile', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Avatar
              Center(
                child: Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    color: AppColors.cardBg,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.primaryAmber, width: 2),
                  ),
                  child: const Icon(
                    Icons.person,
                    size: 50,
                    color: AppColors.primaryAmber,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              Center(
                child: Text(_name, style: TailwindTheme.h2),
              ),
              const SizedBox(height: 4),
              Center(
                child: Text('Patient ID: NN-2026-8812', style: TailwindTheme.caption),
              ),

              const SizedBox(height: 36),

              _profileCard(Icons.email_outlined, 'Registered Email', _email),
              const SizedBox(height: 12),
              _profileCard(Icons.phone_outlined, 'Emergency Contact', '+91 98765 43210'),
              const SizedBox(height: 12),
              _profileCard(Icons.storage_outlined, 'Database Engine', 'SQLite (Local Encrypted Storage)'),

              const Spacer(),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.riskHigh,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  icon: const Icon(Icons.logout),
                  label: const Text('LOG OUT ACCOUNT'),
                  onPressed: _handleLogout,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _profileCard(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Row(
        children: [
          Icon(icon, color: AppColors.primaryAmber, size: 24),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TailwindTheme.caption),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    color: AppColors.textMain,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}