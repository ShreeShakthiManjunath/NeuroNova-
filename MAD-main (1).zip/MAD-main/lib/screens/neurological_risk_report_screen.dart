import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';
import '../widgets/analysis_charts.dart';

class NeurologicalRiskReportScreen extends StatelessWidget {
  const NeurologicalRiskReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Neurological Risk Report', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Overall Risk Badge
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),
                decoration: TailwindTheme.cardDecoration(bg: Colors.white),
                child: Row(
                  children: [
                    DonutChart(
                      size: 84,
                      strokeWidth: 10,
                      total: 100,
                      segments: const [DonutSegment(62, AppColors.riskModerate)],
                      center: const Text(
                        '62',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textMain,
                        ),
                      ),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('Overall Risk Level', style: TailwindTheme.caption),
                          SizedBox(height: 4),
                          Text(
                            'Moderate Risk',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: AppColors.riskModerate,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text('Composite Index: 62/100', style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              const Text('Risk Factor Breakdown', style: TailwindTheme.h3),
              const SizedBox(height: 12),

              Expanded(
                child: ListView(
                  children: [
                    ChartCard(
                      title: 'Risk Contribution',
                      subtitle: 'Which domains drive your overall risk - tap to explore',
                      child: InteractivePieChart(
                        size: 150,
                        slices: [
                          PieSlice('Voice', 22, kChartPalette[0]),
                          PieSlice('Memory', 55, kChartPalette[1]),
                          PieSlice('Hand Tremor', 58, kChartPalette[2]),
                          PieSlice('Finger Tapping', 52, kChartPalette[3]),
                          PieSlice('Balance Sway', 60, kChartPalette[4]),
                        ],
                      ),
                    ),
                    _riskBar('Voice Resonance', 'Low Risk', 0.22, AppColors.riskLow),
                    _riskBar('Memory Recall', 'Moderate Risk', 0.55, AppColors.riskModerate),
                    _riskBar('Hand Tremor', 'Moderate Risk', 0.58, AppColors.riskModerate),
                    _riskBar('Finger Tapping', 'Moderate Risk', 0.52, AppColors.riskModerate),
                    _riskBar('Postural Balance Sway', 'Moderate Risk', 0.60, AppColors.riskModerate),
                  ],
                ),
              ),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: TailwindTheme.primaryButtonStyle,
                  onPressed: () => Navigator.pushNamed(context, '/analysis_3d'),
                  child: const Text('VIEW 3D BODY VISUALIZATION'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _riskBar(String name, String level, double riskVal, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.textMain, fontSize: 14)),
              Text(level, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13)),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: riskVal,
              minHeight: 8,
              backgroundColor: AppColors.cardBg,
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ],
      ),
    );
  }
}
