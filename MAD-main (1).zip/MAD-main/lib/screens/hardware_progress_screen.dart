import 'dart:async';
import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class HardwareProgressScreen extends StatefulWidget {
  const HardwareProgressScreen({super.key});

  @override
  State<HardwareProgressScreen> createState() => _HardwareProgressScreenState();
}

class _HardwareProgressScreenState extends State<HardwareProgressScreen> {
  int _tremorProgress = 0;
  int _tappingProgress = 0;
  int _balanceProgress = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startProgressSimulation();
  }

  void _startProgressSimulation() {
    _timer = Timer.periodic(const Duration(milliseconds: 150), (t) {
      if (_tremorProgress < 100) {
        setState(() => _tremorProgress += 4);
      } else if (_tappingProgress < 100) {
        setState(() => _tappingProgress += 5);
      } else if (_balanceProgress < 100) {
        setState(() => _balanceProgress += 5);
      } else {
        _timer?.cancel();
        Future.delayed(const Duration(milliseconds: 600), () {
          if (mounted) {
            Navigator.pushReplacementNamed(context, '/test_results_overview');
          }
        });
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Hardware Test Live Stream', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Live Hardware Telemetry', style: TailwindTheme.h2),
              const SizedBox(height: 6),
              const Text(
                'Please follow the instructions displayed on the Smart Neuro Cube.',
                style: TailwindTheme.body,
              ),
              const SizedBox(height: 32),

              _progressCard(
                icon: Icons.vibration,
                title: 'Hand Tremor Test',
                progress: _tremorProgress,
              ),
              const SizedBox(height: 16),
              _progressCard(
                icon: Icons.touch_app,
                title: 'Finger Tapping Test',
                progress: _tappingProgress,
              ),
              const SizedBox(height: 16),
              _progressCard(
                icon: Icons.accessibility_new,
                title: 'Balance Test',
                progress: _balanceProgress,
              ),

              const Spacer(),

              Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  decoration: BoxDecoration(
                    color: AppColors.cardBg,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.cardBorder),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppColors.primaryAmber,
                        ),
                      ),
                      SizedBox(width: 12),
                      Text(
                        'Sampling accelerometer & gyroscope data...',
                        style: TextStyle(
                          color: AppColors.textMuted,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _progressCard({required IconData icon, required String title, required int progress}) {
    final bool isCompleted = progress == 100;
    final bool isRunning = progress > 0 && progress < 100;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                icon,
                color: isCompleted
                    ? AppColors.riskLow
                    : isRunning
                        ? AppColors.primaryAmber
                        : AppColors.textMuted,
                size: 26,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: AppColors.textMain,
                  ),
                ),
              ),
              Text(
                isCompleted
                    ? '100%'
                    : isRunning
                        ? '$progress%'
                        : 'Waiting...',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: isCompleted
                      ? AppColors.riskLow
                      : isRunning
                          ? AppColors.primaryAmber
                          : AppColors.textMuted,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: progress / 100.0,
              minHeight: 8,
              backgroundColor: AppColors.cardBg,
              valueColor: AlwaysStoppedAnimation<Color>(
                isCompleted ? AppColors.riskLow : AppColors.primaryAmber,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
