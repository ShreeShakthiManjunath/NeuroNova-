import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class EmergencySosScreen extends StatelessWidget {
  const EmergencySosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Emergency Safety & SOS', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight - 48),
                child: IntrinsicHeight(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text('Emergency Distress SOS', style: TailwindTheme.h2),
                      const SizedBox(height: 6),
                      const Text(
                        'Pressing the SOS button will immediately dispatch alerts & live GPS coordinates to emergency caregivers.',
                        textAlign: TextAlign.center,
                        style: TailwindTheme.body,
                      ),
                      const SizedBox(height: 32),

                      // SOS Glowing Red Button
                      GestureDetector(
                        onTap: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('🚨 SOS Alert Dispatched to Emergency Contacts!'),
                              backgroundColor: AppColors.riskHigh,
                              duration: Duration(seconds: 4),
                            ),
                          );
                        },
                        child: Container(
                          width: 160,
                          height: 160,
                          decoration: BoxDecoration(
                            color: AppColors.riskHigh,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.riskHigh.withValues(alpha: 0.4),
                                blurRadius: 40,
                                spreadRadius: 12,
                              ),
                            ],
                          ),
                          child: const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.warning_amber_rounded, size: 50, color: Colors.white),
                              SizedBox(height: 4),
                              Text(
                                'SOS',
                                style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 24),
                      const Text(
                        'Alert will be sent to registered Caregiver Contacts',
                        textAlign: TextAlign.center,
                        style: TailwindTheme.caption,
                      ),
                      const Spacer(),
                      const SizedBox(height: 24),

                      // Call Caregiver & View Contacts
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              style: TailwindTheme.secondaryButtonStyle,
                              icon: const Icon(Icons.phone, color: AppColors.primaryAmber),
                              label: const Text('Call Caregiver'),
                              onPressed: () {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Dialing primary emergency contact...')),
                                );
                              },
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton.icon(
                              style: TailwindTheme.primaryButtonStyle,
                              icon: const Icon(Icons.people_outline),
                              label: const Text('View Contacts'),
                              onPressed: () {
                                _showContactsDialog(context);
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void _showContactsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text('Registered Caregivers', style: TailwindTheme.h3),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            ListTile(
              leading: Icon(Icons.person, color: AppColors.primaryAmber),
              title: Text('Dr. Priya (Primary Caregiver)'),
              subtitle: Text('+91 98765 43210'),
            ),
            ListTile(
              leading: Icon(Icons.local_hospital, color: AppColors.riskHigh),
              title: Text('City Neuro Care Center'),
              subtitle: Text('+91 91234 56789'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CLOSE'),
          ),
        ],
      ),
    );
  }
}
