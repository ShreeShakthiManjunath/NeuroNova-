import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/screening_data.dart';
import '../utils/tailwind_theme.dart';
import '../widgets/analysis_charts.dart';

class TestResultsOverviewScreen extends StatelessWidget {
  const TestResultsOverviewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Test Results Overview', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Comprehensive Test Scores', style: TailwindTheme.h2),
              const SizedBox(height: 6),
              const Text(
                'Individual performance scores across software & hardware test suites.',
                style: TailwindTheme.body,
              ),
              const SizedBox(height: 24),

              Expanded(
                child: ListView(
                  children: [
                    ChartCard(
                      title: 'Performance Radar',
                      subtitle: 'All five tests at a glance',
                      child: Column(
                        children: [
                          ScoreRadarChart(
                            labels: ScreeningData.shortNames,
                            values: ScreeningData.scores,
                          ),
                          const SizedBox(height: 6),
                          const ChartLegend(items: [
                            LegendItem('Your scores', AppColors.primaryAmber),
                            LegendItem('Low-risk threshold (75)', AppColors.riskLow),
                          ]),
                        ],
                      ),
                    ),
                    _riskDistributionCard(),
                    const Padding(
                      padding: EdgeInsets.only(top: 4, bottom: 12),
                      child: Text('Individual Scores', style: TailwindTheme.h3),
                    ),
                    _scoreCard('Voice Assessment Test', 78, Icons.mic, 'Software Speech Processing'),
                    _scoreCard('Sequence Memory Test', 72, Icons.psychology, 'Cognitive Recall Game'),
                    _scoreCard('Hand Tremor Assessment', 68, Icons.vibration, 'Hardware Sensor Telemetry'),
                    _scoreCard('Finger Tapping Cadence', 70, Icons.touch_app, 'Hardware Sensor Telemetry'),
                    _scoreCard('Postural Balance Sway', 65, Icons.accessibility_new, 'Hardware Sensor Telemetry'),
                  ],
                ),
              ),

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: TailwindTheme.primaryButtonStyle,
                  onPressed: () => Navigator.pushNamed(context, '/risk_report'),
                  child: const Text('VIEW NEUROLOGICAL RISK REPORT'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _riskDistributionCard() {
    final scores = ScreeningData.scores;
    final low = scores.where((v) => v >= 75).length;
    final moderate = scores.where((v) => v >= 60 && v < 75).length;
    final high = scores.where((v) => v < 60).length;

    return ChartCard(
      title: 'Risk Distribution',
      subtitle: 'Tap a slice or a row to pull it out',
      child: InteractivePieChart(
        size: 150,
        unit: 'tests',
        slices: [
          PieSlice('Low risk (75+)', low.toDouble(), AppColors.riskLow),
          PieSlice('Moderate (60-74)', moderate.toDouble(), AppColors.riskModerate),
          PieSlice('High risk (<60)', high.toDouble(), AppColors.riskHigh),
        ],
      ),
    );
  }

  Widget _scoreCard(String title, int score, IconData icon, String subtitle) {
    final Color scoreColor = score >= 75
        ? AppColors.riskLow
        : score >= 60
            ? AppColors.riskModerate
            : AppColors.riskHigh;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.cardBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: AppColors.primaryAmber, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: AppColors.textMain,
                  ),
                ),
                const SizedBox(height: 4),
                Text(subtitle, style: TailwindTheme.caption),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: scoreColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: scoreColor.withValues(alpha: 0.3)),
            ),
            child: Text(
              '$score / 100',
              style: TextStyle(
                color: scoreColor,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
