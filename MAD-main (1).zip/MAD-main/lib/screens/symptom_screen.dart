import 'package:flutter/material.dart';
import '../services/gemini_service.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class SymptomScreen extends StatefulWidget {
  const SymptomScreen({super.key});

  @override
  State<SymptomScreen> createState() => _SymptomScreenState();
}

class _SymptomScreenState extends State<SymptomScreen> {
  final GeminiService _geminiService = GeminiService();

  // Primary symptom categories for Stage 0
  final List<Map<String, dynamic>> _primaryCategories = [
    {'title': 'Tremors & Shaking', 'icon': Icons.vibration, 'desc': 'Hand tremors, resting shaking, or finger stiffness'},
    {'title': 'Memory & Concentration', 'icon': Icons.psychology, 'desc': 'Forgetfulness, word recall pauses, or confusion'},
    {'title': 'Dizziness & Balance', 'icon': Icons.accessibility_new, 'desc': 'Unsteadiness, vertigo, or stumbling while walking'},
    {'title': 'Voice & Speech Changes', 'icon': Icons.mic, 'desc': 'Voice volume drop, shakiness, or slurred words'},
    {'title': 'Headache & Numbness', 'icon': Icons.flash_on, 'desc': 'Facial/arm tingling, sharp pain, or light sensitivity'},
  ];

  int _currentStep = 0; // 0: Select Category, 1..4: AI Nested Questions, 5: AI Summary
  String _selectedCategory = '';
  final List<Map<String, String>> _qaHistory = [];

  bool _isLoadingQuestion = false;
  String _currentQuestion = '';
  List<String> _currentOptions = [];

  bool _isGeneratingSummary = false;
  Map<String, dynamic>? _aiSummaryResult;

  void _selectCategory(String category) {
    setState(() {
      _selectedCategory = category;
      _currentStep = 1;
      _qaHistory.clear();
    });
    _fetchNextAiQuestion();
  }

  Future<void> _fetchNextAiQuestion() async {
    setState(() => _isLoadingQuestion = true);

    final nextQ = await _geminiService.generateNextQuestion(
      previousQa: _qaHistory,
      primaryCategory: _selectedCategory,
    );

    if (mounted) {
      setState(() {
        _currentQuestion = nextQ['question'] ?? 'Please detail your symptom onset:';
        _currentOptions = List<String>.from(nextQ['options'] ?? ['Option 1', 'Option 2', 'Option 3', 'Option 4']);
        _isLoadingQuestion = false;
      });
    }
  }

  void _selectAnswer(String answer) {
    _qaHistory.add({
      'question': _currentQuestion,
      'answer': answer,
    });

    if (_currentStep < 4) {
      setState(() {
        _currentStep++;
      });
      _fetchNextAiQuestion();
    } else {
      _generateFinalSummary();
    }
  }

  Future<void> _generateFinalSummary() async {
    setState(() {
      _currentStep = 5;
      _isGeneratingSummary = true;
    });

    final summary = await _geminiService.generateSymptomSummary(
      qaHistory: _qaHistory,
    );

    if (mounted) {
      setState(() {
        _aiSummaryResult = summary;
        _isGeneratingSummary = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () {
            if (_currentStep > 0 && _currentStep < 5) {
              setState(() {
                _currentStep--;
                if (_qaHistory.isNotEmpty) _qaHistory.removeLast();
              });
              if (_currentStep > 0) _fetchNextAiQuestion();
            } else {
              Navigator.pop(context);
            }
          },
        ),
        title: Text(
          _currentStep == 0
              ? 'Adaptive Symptom Screener'
              : _currentStep == 5
                  ? 'AI Symptom Evaluation'
                  : 'AI Diagnostic Question $_currentStep of 4',
          style: TailwindTheme.h3,
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: _buildStepContent(),
        ),
      ),
    );
  }

  Widget _buildStepContent() {
    if (_currentStep == 0) {
      return _buildCategorySelection();
    } else if (_currentStep >= 1 && _currentStep <= 4) {
      return _buildNestedQuestionView();
    } else {
      return _buildAiSummaryView();
    }
  }

  /// Step 0: Select Chief Neurological Symptom Area
  Widget _buildCategorySelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Chief Neurological Symptom', style: TailwindTheme.h2),
        const SizedBox(height: 6),
        const Text(
          'Select your primary symptom concern to start AI adaptive diagnostic questions.',
          style: TailwindTheme.body,
        ),
        const SizedBox(height: 20),
        Expanded(
          child: ListView.builder(
            itemCount: _primaryCategories.length,
            itemBuilder: (context, index) {
              final item = _primaryCategories[index];
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                decoration: TailwindTheme.cardDecoration(bg: Colors.white),
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppColors.cardBg,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(item['icon'] as IconData, color: AppColors.primaryAmber, size: 28),
                  ),
                  title: Text(
                    item['title'] as String,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.textMain),
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(item['desc'] as String, style: TailwindTheme.caption),
                  ),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: AppColors.primaryAmber),
                  onTap: () => _selectCategory(item['title'] as String),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  /// Step 1 to 4: Dynamic AI Nested Questions
  Widget _buildNestedQuestionView() {
    if (_isLoadingQuestion) {
      return Center(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: TailwindTheme.cardDecoration(bg: Colors.white),
            child: const Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(color: AppColors.primaryAmber),
                SizedBox(height: 16),
                Text(
                  'Gemini AI is analyzing your response and generating the next targeted clinical question...',
                  textAlign: TextAlign.center,
                  style: TailwindTheme.body,
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Progress Bar
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: _currentStep / 4.0,
            minHeight: 8,
            backgroundColor: AppColors.cardBg,
            valueColor: const AlwaysStoppedAnimation<Color>(AppColors.primaryAmber),
          ),
        ),
        const SizedBox(height: 24),

        // Question Banner Card
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: TailwindTheme.cardDecoration(bg: Colors.white),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.cardBg,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'AI QUESTION $_currentStep / 4',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primaryAmber,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _selectedCategory,
                    style: TailwindTheme.caption,
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                _currentQuestion,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textMain,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),

        const Text('Select the best matching option:', style: TailwindTheme.caption),
        const SizedBox(height: 12),

        // Multiple Choice Options List
        Expanded(
          child: ListView.builder(
            itemCount: _currentOptions.length,
            itemBuilder: (context, index) {
              final optionText = _currentOptions[index];
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                decoration: TailwindTheme.cardDecoration(bg: Colors.white),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  leading: CircleAvatar(
                    radius: 14,
                    backgroundColor: AppColors.cardBg,
                    child: Text(
                      String.fromCharCode(65 + index),
                      style: const TextStyle(
                        color: AppColors.primaryAmber,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  title: Text(
                    optionText,
                    style: const TextStyle(
                      color: AppColors.textMain,
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                    ),
                  ),
                  trailing: const Icon(Icons.chevron_right, color: AppColors.primaryAmber),
                  onTap: () => _selectAnswer(optionText),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  /// Step 5: Final AI Neurological Symptom Summary View
  Widget _buildAiSummaryView() {
    if (_isGeneratingSummary || _aiSummaryResult == null) {
      return Center(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: TailwindTheme.cardDecoration(bg: Colors.white),
            child: const Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(color: AppColors.primaryAmber),
                SizedBox(height: 18),
                Text(
                  'Synthesizing 4-Stage Adaptive AI Diagnostic Summary...',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textMain,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final summary = _aiSummaryResult!;
    final String riskLevel = summary['risk_level'] ?? 'Moderate Risk';
    final String summaryText = summary['summary'] ?? '';
    final List<String> observations = List<String>.from(summary['observations'] ?? []);
    final Color riskColor = riskLevel.contains('High')
        ? AppColors.riskHigh
        : riskLevel.contains('Low')
            ? AppColors.riskLow
            : AppColors.riskModerate;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Risk Header Card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(22),
            decoration: TailwindTheme.cardDecoration(bg: Colors.white),
            child: Column(
              children: [
                const Text('ADAPTIVE SYMPTOM EVALUATION', style: TailwindTheme.caption),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  decoration: BoxDecoration(
                    color: riskColor.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: riskColor.withValues(alpha: 0.3)),
                  ),
                  child: Text(
                    riskLevel,
                    style: TextStyle(
                      color: riskColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Based on 4-stage nested dynamic answers for $_selectedCategory',
                  style: TailwindTheme.caption,
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Executive Summary Card
          const Text('Gemini AI Executive Summary', style: TailwindTheme.h3),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: TailwindTheme.cardDecoration(),
            child: Text(
              summaryText,
              style: const TextStyle(
                fontSize: 14,
                color: AppColors.textMain,
                height: 1.5,
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Key Clinical Observations
          const Text('Clinical Observations', style: TailwindTheme.h3),
          const SizedBox(height: 8),
          ...observations.map((obs) => Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: Row(
                  children: [
                    const Icon(Icons.check_circle_outline, color: AppColors.riskLow, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(obs, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary)),
                    ),
                  ],
                ),
              )),
          const SizedBox(height: 20),

          // Q&A Transcript Accordion
          ExpansionTile(
            title: const Text('Review Q&A Transcript (4 Steps)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            children: _qaHistory.map((qa) {
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: TailwindTheme.cardDecoration(bg: Colors.white),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Q: ${qa['question']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppColors.textMain)),
                    const SizedBox(height: 4),
                    Text('A: ${qa['answer']}', style: const TextStyle(color: AppColors.primaryAmber, fontWeight: FontWeight.w600, fontSize: 13)),
                  ],
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 24),

          // Navigation Buttons
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              style: TailwindTheme.primaryButtonStyle,
              onPressed: () => Navigator.pushNamed(context, '/voice_test'),
              child: const Text('PROCEED TO VOICE ASSESSMENT'),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: OutlinedButton(
              style: TailwindTheme.secondaryButtonStyle,
              onPressed: () => Navigator.pushReplacementNamed(context, '/home'),
              child: const Text('RETURN TO DASHBOARD'),
            ),
          ),
        ],
      ),
    );
  }
}