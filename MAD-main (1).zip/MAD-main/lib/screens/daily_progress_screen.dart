import 'package:flutter/material.dart';
import '../utils/app_colors.dart';
import '../utils/screening_data.dart';
import '../utils/tailwind_theme.dart';
import '../widgets/analysis_charts.dart';

class DailyProgressScreen extends StatefulWidget {
  const DailyProgressScreen({super.key});

  @override
  State<DailyProgressScreen> createState() => _DailyProgressScreenState();
}

class _DailyProgressScreenState extends State<DailyProgressScreen> {
  static const String _overall = 'Overall';
  String _series = _overall;

  List<double> get _values => _series == _overall
      ? ScreeningData.trendOverall
      : ScreeningData.trendBySeries[_series]!;

  @override
  Widget build(BuildContext context) {
    final double avg = ScreeningData.average;
    final values = _values;
    final double change = values.last - values.first;
    final bool improving = change >= 0;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textMain),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Daily Progress Tracking', style: TailwindTheme.h3),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('21 July 2026', style: TailwindTheme.h2),
                    const SizedBox(height: 6),
                    const Text('Daily neurological screening metrics tracking',
                        style: TailwindTheme.body),
                    const SizedBox(height: 20),

                    // Summary stats
                    Row(
                      children: [
                        Expanded(
                          child: _statCard(
                            'Tests Completed',
                            '${ScreeningData.todayScores.length} / ${ScreeningData.todayScores.length}',
                            AppColors.primaryAmber,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _statCard(
                            'Average Score',
                            '${avg.round()} / 100',
                            scoreBandColor(avg),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),

                    const Text('Progress Overview Trend', style: TailwindTheme.h3),
                    const SizedBox(height: 12),

                    // Trend chart with series selector
                    ChartCard(
                      title: _series == _overall ? 'Overall score' : '$_series score',
                      subtitle: improving
                          ? 'Up ${change.round()} points since ${ScreeningData.trendLabels.first}'
                          : 'Down ${change.abs().round()} points since ${ScreeningData.trendLabels.first}',
                      trailing: Icon(
                        improving ? Icons.trending_up : Icons.trending_down,
                        color: improving ? AppColors.riskLow : AppColors.riskHigh,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _seriesChips(),
                          const SizedBox(height: 12),
                          TrendLineChart(
                            key: ValueKey(_series),
                            labels: ScreeningData.trendLabels,
                            values: values,
                          ),
                        ],
                      ),
                    ),

                    // Per-test bar chart
                    ChartCard(
                      title: 'Today\'s Score by Test',
                      subtitle: 'Bars above the dashed line are in the low-risk range',
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ScoreBarChart(
                            labels: ScreeningData.shortNames,
                            values: ScreeningData.scores,
                          ),
                          const SizedBox(height: 10),
                          const ChartLegend(items: ChartLegend.riskBands),
                        ],
                      ),
                    ),

                    // Before vs. now grouped bars
                    ChartCard(
                      title: 'Then vs. Now',
                      subtitle:
                          '${ScreeningData.trendLabels.first} compared with ${ScreeningData.trendLabels.last}',
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ComparisonBarChart(
                            labels: ScreeningData.shortNames,
                            before: [
                              for (final s in ScreeningData.trendBySeries.values) s.first,
                            ],
                            after: [
                              for (final s in ScreeningData.trendBySeries.values) s.last,
                            ],
                          ),
                          const SizedBox(height: 10),
                          ChartLegend(items: [
                            LegendItem(ScreeningData.trendLabels.first,
                                const Color(0xFFFDE68A)),
                            LegendItem(ScreeningData.trendLabels.last,
                                AppColors.primaryAmber),
                          ]),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 16),
              child: SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: TailwindTheme.primaryButtonStyle,
                  onPressed: () => Navigator.pushNamed(context, '/doctor'),
                  child: const Text('CONSULT RECOMMENDED DOCTOR'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _seriesChips() {
    final names = [_overall, ...ScreeningData.trendBySeries.keys];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (final name in names)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                label: Text(
                  name,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: _series == name ? Colors.white : AppColors.textMain,
                  ),
                ),
                selected: _series == name,
                showCheckmark: false,
                selectedColor: AppColors.primaryAmber,
                backgroundColor: AppColors.cardBg,
                side: const BorderSide(color: AppColors.cardBorder),
                onSelected: (_) => setState(() => _series = name),
              ),
            ),
        ],
      ),
    );
  }

  Widget _statCard(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: TailwindTheme.cardDecoration(bg: Colors.white),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TailwindTheme.caption),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
