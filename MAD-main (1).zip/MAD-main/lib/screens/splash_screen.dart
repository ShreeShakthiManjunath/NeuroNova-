import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../services/auth_service.dart';
import '../utils/app_colors.dart';
import '../utils/tailwind_theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final AuthService _authService = AuthService();

  @override
  void initState() {
    super.initState();
    _startInitialization();
  }

  Future<void> _startInitialization() async {
    await Future.delayed(const Duration(seconds: 2));
    final bool isLoggedIn = await _authService.isUserLoggedIn();
    final bool isNew = await _authService.isNewUser();

    if (!mounted) return;

    if (isLoggedIn) {
      Navigator.pushReplacementNamed(context, '/home');
    } else if (isNew) {
      // New user lands directly on Create Account / Signup page!
      Navigator.pushReplacementNamed(context, '/register');
    } else {
      Navigator.pushReplacementNamed(context, '/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final double circleSize = (constraints.maxHeight * 0.28).clamp(160.0, 220.0);
            final double iconSize = circleSize * 0.60;

            return Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "NeuroNova",
                      style: TextStyle(
                        color: AppColors.primaryAmber,
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Smart Neurological\nScreening System",
                      textAlign: TextAlign.center,
                      style: TailwindTheme.body,
                    ),
                    const SizedBox(height: 32),
                    Container(
                      width: circleSize,
                      height: circleSize,
                      decoration: BoxDecoration(
                        color: AppColors.cardBg,
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.cardBorder, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primaryAmber.withValues(alpha: 0.25),
                            blurRadius: 50,
                            spreadRadius: 10,
                          ),
                        ],
                      ),
                      child: Center(
                        child: SvgPicture.asset(
                          "assets/images/brain.svg",
                          width: iconSize,
                          height: iconSize,
                          placeholderBuilder: (context) => Icon(
                            Icons.psychology,
                            size: iconSize,
                            color: AppColors.primaryAmber,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),
                    const Text(
                      "Initializing System...",
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const SizedBox(
                      width: 200,
                      child: LinearProgressIndicator(
                        minHeight: 6,
                        backgroundColor: Color(0xFFFDE68A),
                        valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryAmber),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}